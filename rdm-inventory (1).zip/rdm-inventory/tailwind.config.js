export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: 'var(--bg)', card: 'var(--card)', tx: 'var(--tx)', mu: 'var(--mu)', bd: 'var(--bd)',
        side: 'var(--side)', brand: 'var(--p)', teal: 'var(--c)', warn: 'var(--o)', danger: 'var(--r)', ok: 'var(--g)',
      },
      fontFamily: { sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'] },
    },
  },
  plugins: [],
}
