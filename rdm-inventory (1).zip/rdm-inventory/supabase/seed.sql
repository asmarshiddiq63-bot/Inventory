-- Data contoh (opsional) — sama dengan data demo prototipe
insert into public.items (name, category, kind, size, unit, price, min_stock, opening_qty, location) values
 ('Laptop Dell Latitude 5440','Elektronik','aset','14 inch','unit',14500000,2,8,'Gudang A'),
 ('Printer Epson L3250','Elektronik','aset','A4','unit',2750000,2,5,'Gudang A'),
 ('Kabel LAN Cat6','Jaringan','persediaan','305 m','roll',1250000,5,12,'Rak B2'),
 ('Switch TP-Link 24 Port','Jaringan','aset','24 port','unit',2100000,1,3,'Rak B1'),
 ('Kursi Ergonomis','Furnitur','aset','Standar','unit',1850000,3,15,'Gudang C'),
 ('Kertas HVS A4 80gr','ATK','persediaan','A4','rim',52000,10,40,'Rak D1'),
 ('Tinta Epson 003 Hitam','ATK','persediaan','65 ml','botol',95000,5,4,'Rak D2');
