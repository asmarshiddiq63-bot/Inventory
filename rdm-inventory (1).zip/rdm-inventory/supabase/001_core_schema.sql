-- =====================================================================
-- RDM Inventory & Aset — PT Revolutek Dananjaya Mandiri
-- 001: tabel inti, view stok, trigger
-- Jalankan di Supabase SQL Editor (urutan: 001 -> 002 -> seed opsional)
-- =====================================================================
create extension if not exists pgcrypto;

create type app_role      as enum ('administrator','petugas','approver','viewer');
create type item_kind     as enum ('persediaan','aset');
create type movement_type as enum ('masuk','keluar','koreksi');
create type asset_status  as enum ('tersedia','dipakai','servis','rusak');
create type service_status as enum ('proses','selesai','batal');
create type opname_status as enum ('menunggu','disetujui','ditolak');

-- ---------- profil pengguna (user baru otomatis = viewer) ----------
create table public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text,
  full_name  text,
  role       app_role not null default 'viewer',
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (new.id, new.email,
          coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
          'viewer');
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- master barang (stok dilacak PER ITEM; tiap size = kode sendiri) ----------
create sequence public.item_code_seq;

create or replace function public.set_item_code() returns trigger
language plpgsql as $$
begin
  if new.code is null or btrim(new.code) = '' then
    new.code := 'RDM-' || lpad(nextval('public.item_code_seq')::text, 4, '0');
  else
    new.code := upper(btrim(new.code));
  end if;
  return new;
end $$;

create table public.items (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique,
  name        text not null,
  category    text not null default 'Umum',
  kind        item_kind not null default 'persediaan',
  size        text default '-',
  unit        text not null default 'unit',
  price       numeric(15,2) not null default 0 check (price >= 0),
  min_stock   int not null default 0 check (min_stock >= 0),
  opening_qty int not null default 0 check (opening_qty >= 0),
  location    text default '-',
  description text,
  photo_url   text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger items_set_code before insert on public.items
  for each row execute function public.set_item_code();

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at := now(); return new; end $$;
create trigger items_touch before update on public.items
  for each row execute function public.touch_updated_at();

-- ---------- opname (hanya persediaan; koreksi baru berlaku setelah disetujui) ----------
create table public.stock_opnames (
  id          uuid primary key default gen_random_uuid(),
  item_id     uuid not null references public.items(id) on delete restrict,
  system_qty  int not null,
  physical_qty int not null check (physical_qty >= 0),
  diff        int generated always as (physical_qty - system_qty) stored,
  opname_date date not null default current_date,
  status      opname_status not null default 'menunggu',
  note        text,
  created_by  uuid default auth.uid() references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  created_at  timestamptz not null default now()
);
create unique index one_pending_opname_per_item on public.stock_opnames(item_id) where status = 'menunggu';

-- ---------- mutasi stok (hanya ditulis lewat RPC) ----------
create table public.stock_movements (
  id            uuid primary key default gen_random_uuid(),
  item_id       uuid not null references public.items(id) on delete restrict,
  type          movement_type not null,
  qty           int not null,
  movement_date date not null default current_date,
  party         text,
  note          text,
  unit_price    numeric(15,2),
  serials       text[],
  ref_opname_id uuid references public.stock_opnames(id),
  created_by    uuid default auth.uid() references auth.users(id),
  created_at    timestamptz not null default now(),
  check ((type = 'koreksi' and qty <> 0) or (type <> 'koreksi' and qty > 0))
);
create index on public.stock_movements(item_id, movement_date desc);

-- ---------- aset per unit (serial number) ----------
create table public.assets (
  id             uuid primary key default gen_random_uuid(),
  item_id        uuid not null references public.items(id) on delete cascade,
  serial_number  text not null unique,
  status         asset_status not null default 'tersedia',
  warranty_until date,
  location       text,
  note           text,
  received_at    date default current_date,
  movement_in_id uuid references public.stock_movements(id) on delete set null,
  created_at     timestamptz not null default now()
);
create index on public.assets(item_id);

-- ---------- servis & maintenance ----------
create table public.service_records (
  id            uuid primary key default gen_random_uuid(),
  item_id       uuid not null references public.items(id) on delete restrict,
  asset_id      uuid references public.assets(id) on delete set null,
  serial_number text,
  issue         text not null,
  vendor        text,
  cost          numeric(15,2) not null default 0 check (cost >= 0),
  start_date    date not null default current_date,
  est_date      date not null default current_date,
  status        service_status not null default 'proses',
  created_by    uuid default auth.uid() references auth.users(id),
  created_at    timestamptz not null default now(),
  check (est_date >= start_date)
);

-- status unit ikut servis
create or replace function public.sync_asset_service() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.asset_id is not null then
    if new.status = 'proses' then
      update assets set status = 'servis' where id = new.asset_id;
    else
      update assets set status = 'tersedia' where id = new.asset_id and status = 'servis';
    end if;
  end if;
  return new;
end $$;
create trigger service_sync_asset after insert or update on public.service_records
  for each row execute function public.sync_asset_service();

-- ---------- view stok: stok = awal + masuk - keluar + koreksi ----------
create or replace view public.v_item_stock with (security_invoker = true) as
select i.*,
       (i.opening_qty + coalesce(sum(case m.type
           when 'masuk'  then m.qty
           when 'keluar' then -m.qty
           else m.qty end), 0))::int as stock
from public.items i
left join public.stock_movements m on m.item_id = i.id
group by i.id;
