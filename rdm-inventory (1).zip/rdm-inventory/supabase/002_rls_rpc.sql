-- =====================================================================
-- 002: helper role, RLS, RPC transaksi stok, storage foto, realtime
-- =====================================================================
create or replace function public.has_role(roles app_role[]) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role = any(roles) from public.profiles where id = auth.uid()), false)
$$;

alter table public.profiles        enable row level security;
alter table public.items           enable row level security;
alter table public.assets          enable row level security;
alter table public.stock_movements enable row level security;
alter table public.stock_opnames   enable row level security;
alter table public.service_records enable row level security;

-- baca: semua user login
create policy "read profiles"  on public.profiles        for select to authenticated using (true);
create policy "read items"     on public.items           for select to authenticated using (true);
create policy "read assets"    on public.assets          for select to authenticated using (true);
create policy "read movements" on public.stock_movements for select to authenticated using (true);
create policy "read opnames"   on public.stock_opnames   for select to authenticated using (true);
create policy "read services"  on public.service_records for select to authenticated using (true);

-- tulis langsung: master & servis oleh admin/petugas; role oleh admin.
-- stock_movements, stock_opnames: TIDAK ada policy tulis -> hanya lewat RPC.
create policy "admin set role" on public.profiles for update to authenticated
  using (public.has_role(array['administrator']::app_role[]))
  with check (public.has_role(array['administrator']::app_role[]));
create policy "write items ins" on public.items for insert to authenticated
  with check (public.has_role(array['administrator','petugas']::app_role[]));
create policy "write items upd" on public.items for update to authenticated
  using (public.has_role(array['administrator','petugas']::app_role[]))
  with check (public.has_role(array['administrator','petugas']::app_role[]));
create policy "write assets upd" on public.assets for update to authenticated
  using (public.has_role(array['administrator','petugas']::app_role[]))
  with check (public.has_role(array['administrator','petugas']::app_role[]));
create policy "write service ins" on public.service_records for insert to authenticated
  with check (public.has_role(array['administrator','petugas']::app_role[]));
create policy "write service upd" on public.service_records for update to authenticated
  using (public.has_role(array['administrator','petugas']::app_role[]))
  with check (public.has_role(array['administrator','petugas']::app_role[]));
create policy "admin del service" on public.service_records for delete to authenticated
  using (public.has_role(array['administrator']::app_role[]));

-- ---------------------------------------------------------------------
-- RPC: barang masuk
-- ---------------------------------------------------------------------
create or replace function public.rpc_stock_in(
  p_item uuid, p_qty int, p_date date, p_party text, p_price numeric, p_note text,
  p_serials text[] default '{}', p_warranty date default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_sn text; v_serials text[]; v_item items;
begin
  if not has_role(array['administrator','petugas']::app_role[]) then
    raise exception 'Anda tidak punya izin mencatat barang masuk'; end if;
  if p_qty is null or p_qty <= 0 then raise exception 'Jumlah harus lebih dari 0'; end if;

  select * into v_item from items where id = p_item and is_active for update;
  if not found then raise exception 'Barang tidak ditemukan'; end if;

  select coalesce(array_agg(distinct upper(btrim(s))) filter (where btrim(s) <> ''), '{}')
    into v_serials from unnest(coalesce(p_serials, '{}')) s;
  if cardinality(v_serials) > p_qty then
    raise exception 'Jumlah serial number melebihi jumlah masuk'; end if;

  insert into stock_movements (item_id, type, qty, movement_date, party, note, unit_price, serials)
  values (p_item, 'masuk', p_qty, coalesce(p_date, current_date), nullif(btrim(p_party),''),
          nullif(btrim(p_note),''), nullif(p_price, 0),
          case when cardinality(v_serials) = 0 then null else v_serials end)
  returning id into v_id;

  foreach v_sn in array v_serials loop
    begin
      insert into assets (item_id, serial_number, warranty_until, location, received_at, movement_in_id)
      values (p_item, v_sn, p_warranty, v_item.location, coalesce(p_date, current_date), v_id);
    exception when unique_violation then
      raise exception 'Serial number % sudah terdaftar', v_sn;
    end;
  end loop;

  if p_price is not null and p_price > 0 then
    update items set price = p_price where id = p_item;
  end if;
  return v_id;
end $$;

-- ---------------------------------------------------------------------
-- RPC: barang keluar (kunci baris item -> stok tidak bisa minus)
-- ---------------------------------------------------------------------
create or replace function public.rpc_stock_out(
  p_item uuid, p_qty int, p_date date, p_party text, p_note text, p_serials text[] default '{}'
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_sn text; v_serials text[]; v_stock int;
begin
  if not has_role(array['administrator','petugas']::app_role[]) then
    raise exception 'Anda tidak punya izin mencatat barang keluar'; end if;
  if p_qty is null or p_qty <= 0 then raise exception 'Jumlah harus lebih dari 0'; end if;

  perform 1 from items where id = p_item and is_active for update;
  if not found then raise exception 'Barang tidak ditemukan'; end if;

  select stock into v_stock from v_item_stock where id = p_item;
  if p_qty > v_stock then raise exception 'Stok tidak cukup (tersedia %)', v_stock; end if;

  select coalesce(array_agg(distinct upper(btrim(s))) filter (where btrim(s) <> ''), '{}')
    into v_serials from unnest(coalesce(p_serials, '{}')) s;
  if cardinality(v_serials) > p_qty then
    raise exception 'Jumlah serial number melebihi jumlah keluar'; end if;

  foreach v_sn in array v_serials loop
    update assets set status = 'dipakai'
     where item_id = p_item and serial_number = v_sn and status = 'tersedia';
    if not found then
      raise exception 'Serial number % tidak tersedia pada barang ini', v_sn; end if;
  end loop;

  insert into stock_movements (item_id, type, qty, movement_date, party, note, serials)
  values (p_item, 'keluar', p_qty, coalesce(p_date, current_date), nullif(btrim(p_party),''),
          nullif(btrim(p_note),''), case when cardinality(v_serials) = 0 then null else v_serials end)
  returning id into v_id;
  return v_id;
end $$;

-- edit barang keluar (jumlah, tanggal, tujuan, catatan)
create or replace function public.rpc_update_stock_out(
  p_id uuid, p_qty int, p_date date, p_party text, p_note text
) returns void language plpgsql security definer set search_path = public as $$
declare m stock_movements; v_stock int;
begin
  if not has_role(array['administrator','petugas']::app_role[]) then
    raise exception 'Anda tidak punya izin mengubah transaksi'; end if;
  select * into m from stock_movements where id = p_id for update;
  if not found or m.type <> 'keluar' then raise exception 'Transaksi keluar tidak ditemukan'; end if;
  if p_qty is null or p_qty <= 0 then raise exception 'Jumlah harus lebih dari 0'; end if;
  if m.serials is not null and p_qty < cardinality(m.serials) then
    raise exception 'Jumlah tidak boleh kurang dari jumlah serial number tercatat'; end if;

  perform 1 from items where id = m.item_id for update;
  select stock into v_stock from v_item_stock where id = m.item_id;
  if p_qty > v_stock + m.qty then
    raise exception 'Stok tidak cukup (tersedia %)', v_stock + m.qty; end if;

  update stock_movements
     set qty = p_qty, movement_date = coalesce(p_date, movement_date),
         party = nullif(btrim(p_party),''), note = nullif(btrim(p_note),'')
   where id = p_id;
end $$;

-- hapus transaksi masuk/keluar (administrator saja; koreksi opname tidak bisa dihapus)
create or replace function public.rpc_delete_movement(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare m stock_movements; v_stock int;
begin
  if not has_role(array['administrator']::app_role[]) then
    raise exception 'Hanya administrator yang dapat menghapus transaksi'; end if;
  select * into m from stock_movements where id = p_id for update;
  if not found then raise exception 'Transaksi tidak ditemukan'; end if;
  if m.type = 'koreksi' then raise exception 'Koreksi opname tidak dapat dihapus'; end if;

  perform 1 from items where id = m.item_id for update;
  if m.type = 'masuk' then
    if exists (select 1 from assets where movement_in_id = m.id and status <> 'tersedia') then
      raise exception 'Sebagian unit sudah dipakai/diservis, transaksi tidak bisa dihapus'; end if;
    select stock into v_stock from v_item_stock where id = m.item_id;
    if v_stock - m.qty < 0 then
      raise exception 'Stok sudah terpakai, transaksi tidak bisa dihapus'; end if;
    delete from assets where movement_in_id = m.id;
  else
    update assets set status = 'tersedia'
     where item_id = m.item_id and serial_number = any(coalesce(m.serials, '{}')) and status = 'dipakai';
  end if;
  delete from stock_movements where id = p_id;
end $$;

-- ---------------------------------------------------------------------
-- RPC: stock opname (ajukan -> disetujui/ditolak)
-- ---------------------------------------------------------------------
create or replace function public.rpc_submit_opname(p_item uuid, p_physical int, p_note text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_item items; v_stock int; v_id uuid;
begin
  if not has_role(array['administrator','petugas']::app_role[]) then
    raise exception 'Anda tidak punya izin melakukan opname'; end if;
  if p_physical is null or p_physical < 0 then raise exception 'Stok fisik tidak valid'; end if;
  select * into v_item from items where id = p_item and is_active;
  if not found then raise exception 'Barang tidak ditemukan'; end if;
  if v_item.kind <> 'persediaan' then raise exception 'Opname hanya untuk barang persediaan'; end if;
  select stock into v_stock from v_item_stock where id = p_item;
  begin
    insert into stock_opnames (item_id, system_qty, physical_qty, note)
    values (p_item, v_stock, p_physical, nullif(btrim(p_note),'')) returning id into v_id;
  exception when unique_violation then
    raise exception 'Sudah ada opname menunggu persetujuan untuk % ', v_item.name;
  end;
  return v_id;
end $$;

create or replace function public.rpc_review_opname(p_id uuid, p_approve boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare o stock_opnames; v_stock int; v_diff int;
begin
  if not has_role(array['administrator','approver']::app_role[]) then
    raise exception 'Hanya approver/administrator yang dapat menyetujui opname'; end if;
  select * into o from stock_opnames where id = p_id for update;
  if not found then raise exception 'Opname tidak ditemukan'; end if;
  if o.status <> 'menunggu' then raise exception 'Opname sudah diproses'; end if;

  if p_approve then
    perform 1 from items where id = o.item_id for update;
    select stock into v_stock from v_item_stock where id = o.item_id;
    v_diff := o.physical_qty - v_stock;
    if v_diff <> 0 then
      insert into stock_movements (item_id, type, qty, movement_date, party, note, ref_opname_id)
      values (o.item_id, 'koreksi', v_diff, current_date, 'Stock opname',
              coalesce(p_note, o.note, 'Koreksi hasil opname'), o.id);
    end if;
    update stock_opnames set status = 'disetujui', approved_by = auth.uid(), approved_at = now(),
           note = coalesce(p_note, note) where id = p_id;
  else
    update stock_opnames set status = 'ditolak', approved_by = auth.uid(), approved_at = now(),
           note = coalesce(p_note, note) where id = p_id;
  end if;
end $$;

revoke execute on function public.rpc_stock_in, public.rpc_stock_out, public.rpc_update_stock_out,
  public.rpc_delete_movement, public.rpc_submit_opname, public.rpc_review_opname from public, anon;
grant execute on function public.rpc_stock_in, public.rpc_stock_out, public.rpc_update_stock_out,
  public.rpc_delete_movement, public.rpc_submit_opname, public.rpc_review_opname to authenticated;

-- ---------------------------------------------------------------------
-- Storage foto barang + realtime
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public) values ('item-photos', 'item-photos', true)
on conflict (id) do nothing;

create policy "photos read" on storage.objects for select using (bucket_id = 'item-photos');
create policy "photos insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'item-photos' and public.has_role(array['administrator','petugas']::app_role[]));

alter publication supabase_realtime add table
  public.items, public.stock_movements, public.assets, public.service_records, public.stock_opnames;
