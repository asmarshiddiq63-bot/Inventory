import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['icon-192.png', 'icon-512.png'],
      manifest: {
        name: 'RDM Inventory & Aset',
        short_name: 'RDM Inventory',
        description: 'Manajemen inventory dan aset PT Revolutek Dananjaya Mandiri',
        lang: 'id',
        start_url: '/',
        display: 'standalone',
        orientation: 'portrait',
        background_color: '#14173a',
        theme_color: '#14173a',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: { navigateFallback: '/index.html' },
    }),
  ],
})
