# RDM Inventory & Aset — PT Revolutek Dananjaya Mandiri

Aplikasi web inventory & aset (Bahasa Indonesia, zona waktu Asia/Jakarta, mata uang IDR).
Stack: **React + TypeScript + Vite · Tailwind · Supabase (PostgreSQL, Auth, RLS, RPC, Storage, Realtime) · Recharts · QR generator/scanner · PWA** — siap deploy di Vercel.

## 1. Siapkan Supabase
1. Buat project di supabase.com.
2. Buka **SQL Editor**, jalankan berurutan: `supabase/001_core_schema.sql` → `supabase/002_rls_rpc.sql` → (opsional) `supabase/seed.sql`.
3. Daftar akun pertama lewat aplikasi (atau Authentication → Users), lalu jadikan administrator:
   ```sql
   update public.profiles set role = 'administrator' where email = 'email-anda@perusahaan.com';
   ```
   Akun lain bisa diatur dari menu **Pengaturan** (hanya administrator).
4. (Opsional) Authentication → Providers → Email: matikan "Confirm email" bila tidak ingin verifikasi email.

## 2. Jalankan lokal
```bash
cp .env.example .env      # isi VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY (Settings → API)
npm install
npm run dev
```

## 3. Deploy ke Vercel
Import repo → framework Vite → tambahkan Environment Variables `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` → Deploy. (`vercel.json` sudah mengatur SPA routing.)
Di HP Android buka alamatnya di Chrome → menu ⋮ → **Instal aplikasi**.

## Aturan stok (di database, bukan di browser)
- Stok = stok awal + masuk − keluar + koreksi opname yang **disetujui** (view `v_item_stock`).
- Semua perubahan stok lewat RPC transaksional: `rpc_stock_in`, `rpc_stock_out`, `rpc_update_stock_out`, `rpc_delete_movement`, `rpc_submit_opname`, `rpc_review_opname`. Tabel `stock_movements` dan `stock_opnames` tidak bisa ditulis langsung dari klien (RLS).
- Barang keluar mengunci baris item (`FOR UPDATE`) sehingga stok tidak bisa minus walau dua orang input bersamaan.
- Stok dilacak per item (tiap size = kode sendiri); aset ber-serial number dicatat per unit di tabel `assets`; opname hanya untuk barang persediaan.

## Peran
| Peran | Hak |
|---|---|
| Administrator | semua, kelola pengguna, hapus transaksi |
| Petugas Inventory | master, masuk/keluar, servis, ajukan opname |
| Approver | setujui/tolak opname |
| Viewer | hanya melihat (default akun baru) |

## Struktur
```
supabase/   skema, RLS, RPC, seed
src/lib/    supabase client, auth, query hooks, format
src/pages/  Dashboard, Master, Masuk, Keluar, Servis, Opname, QR, Scan, Riwayat, Laporan, Pengaturan
```
