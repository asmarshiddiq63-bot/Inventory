import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from './supabase'
import type { Profile, Role } from './types'

interface AuthState {
  session: Session | null
  profile: Profile | null
  loading: boolean
  role: Role
  isAdmin: boolean
  canWrite: boolean
  canApprove: boolean
  signIn: (email: string, password: string) => Promise<string | null>
  signUp: (email: string, password: string, name: string) => Promise<string | null>
  signOut: () => Promise<void>
}

const Ctx = createContext<AuthState>(null as unknown as AuthState)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      if (!data.session) setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s)
      if (!s) { setProfile(null); setLoading(false) }
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  const uid = session?.user.id
  useEffect(() => {
    if (!uid) return
    let off = false
    setLoading(true)
    supabase.from('profiles').select('*').eq('id', uid).single().then(({ data }) => {
      if (off) return
      setProfile((data as Profile) ?? null)
      setLoading(false)
    })
    return () => { off = true }
  }, [uid])

  const value = useMemo<AuthState>(() => {
    const role: Role = profile?.role ?? 'viewer'
    return {
      session, profile, loading, role,
      isAdmin: role === 'administrator',
      canWrite: role === 'administrator' || role === 'petugas',
      canApprove: role === 'administrator' || role === 'approver',
      signIn: async (email, password) => (await supabase.auth.signInWithPassword({ email, password })).error?.message ?? null,
      signUp: async (email, password, name) =>
        (await supabase.auth.signUp({ email, password, options: { data: { full_name: name } } })).error?.message ?? null,
      signOut: async () => { await supabase.auth.signOut() },
    }
  }, [session, profile, loading])

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
