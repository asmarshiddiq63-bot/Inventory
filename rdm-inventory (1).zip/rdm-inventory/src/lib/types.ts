export type Role = 'administrator' | 'petugas' | 'approver' | 'viewer'
export type Kind = 'persediaan' | 'aset'

export interface Profile { id: string; email: string | null; full_name: string | null; role: Role; created_at: string }

export interface Item {
  id: string; code: string; name: string; category: string; kind: Kind
  size: string | null; unit: string; price: number; min_stock: number; opening_qty: number
  location: string | null; description: string | null; photo_url: string | null
  is_active: boolean; stock: number
}

export interface Movement {
  id: string; item_id: string; type: 'masuk' | 'keluar' | 'koreksi'; qty: number
  movement_date: string; party: string | null; note: string | null; unit_price: number | null
  serials: string[] | null; created_by: string | null; created_at: string
}

export interface Asset {
  id: string; item_id: string; serial_number: string
  status: 'tersedia' | 'dipakai' | 'servis' | 'rusak'
  warranty_until: string | null; location: string | null; received_at: string | null
}

export interface ServiceRec {
  id: string; item_id: string; asset_id: string | null; serial_number: string | null
  issue: string; vendor: string | null; cost: number; start_date: string; est_date: string
  status: 'proses' | 'selesai' | 'batal'; created_by: string | null; created_at: string
}

export interface Opname {
  id: string; item_id: string; system_qty: number; physical_qty: number; diff: number
  opname_date: string; status: 'menunggu' | 'disetujui' | 'ditolak'; note: string | null
  created_by: string | null; approved_by: string | null; approved_at: string | null; created_at: string
}
