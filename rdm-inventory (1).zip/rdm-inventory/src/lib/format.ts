const TZ = 'Asia/Jakarta'

export const rp = (n: number | null | undefined) => 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID')
export const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: TZ })

export const fd = (d?: string | null) =>
  d ? new Date(d.slice(0, 10) + 'T00:00:00+07:00').toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', timeZone: TZ }) : '-'

export const fdt = (d?: string | null) =>
  d ? new Date(d).toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: TZ }) : '-'

export const daysUntil = (d?: string | null): number | null => {
  if (!d) return null
  const a = new Date(d.slice(0, 10) + 'T00:00:00+07:00').getTime()
  const b = new Date(today() + 'T00:00:00+07:00').getTime()
  return Math.round((a - b) / 864e5)
}

/** pisahkan serial number dipisah koma / titik koma / baris baru */
export const toks = (s: string) => s.split(/[,;\n]+/).map((x) => x.trim().toUpperCase()).filter(Boolean)
