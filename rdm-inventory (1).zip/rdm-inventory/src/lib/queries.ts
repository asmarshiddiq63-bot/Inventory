import { useQuery } from '@tanstack/react-query'
import { supabase } from './supabase'
import type { Asset, Item, Movement, Opname, Profile, ServiceRec } from './types'

async function sel<T>(q: PromiseLike<{ data: unknown; error: { message: string } | null }>): Promise<T> {
  const { data, error } = await q
  if (error) throw new Error(error.message)
  return data as T
}

export const useItems = () =>
  useQuery({ queryKey: ['items'], queryFn: () => sel<Item[]>(supabase.from('v_item_stock').select('*').eq('is_active', true).order('code')) })

export const useMovements = () =>
  useQuery({
    queryKey: ['movements'],
    queryFn: () =>
      sel<Movement[]>(supabase.from('stock_movements').select('*').order('movement_date', { ascending: false }).order('created_at', { ascending: false }).limit(5000)),
  })

export const useAssets = () =>
  useQuery({ queryKey: ['assets'], queryFn: () => sel<Asset[]>(supabase.from('assets').select('*').order('serial_number')) })

export const useServices = () =>
  useQuery({ queryKey: ['services'], queryFn: () => sel<ServiceRec[]>(supabase.from('service_records').select('*').order('start_date', { ascending: false })) })

export const useOpnames = () =>
  useQuery({
    queryKey: ['opnames'],
    queryFn: () => sel<Opname[]>(supabase.from('stock_opnames').select('*').order('created_at', { ascending: false }).limit(1000)),
  })

export const useProfiles = () =>
  useQuery({ queryKey: ['profiles'], queryFn: () => sel<Profile[]>(supabase.from('profiles').select('*').order('created_at')) })
