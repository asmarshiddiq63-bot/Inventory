import { supabase } from './supabase'

export async function rpc<T = unknown>(fn: string, args: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.rpc(fn, args)
  if (error) throw new Error(error.message)
  return data as T
}

/** untuk insert/update/delete langsung ke tabel */
export async function db(p: PromiseLike<{ error: { message: string } | null }>) {
  const { error } = await p
  if (error) throw new Error(error.message)
}

/** kompres foto (maks 640px, JPEG) lalu unggah ke Storage, kembalikan URL publik */
export async function uploadPhoto(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('Pilih file gambar (JPG/PNG)')
  const bmp = await createImageBitmap(file)
  const k = Math.min(1, 640 / Math.max(bmp.width, bmp.height))
  const c = document.createElement('canvas')
  c.width = Math.round(bmp.width * k)
  c.height = Math.round(bmp.height * k)
  c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height)
  const blob: Blob = await new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('Gagal memproses gambar'))), 'image/jpeg', 0.75))
  const path = `${crypto.randomUUID()}.jpg`
  const { error } = await supabase.storage.from('item-photos').upload(path, blob, { contentType: 'image/jpeg' })
  if (error) throw new Error(error.message)
  return supabase.storage.from('item-photos').getPublicUrl(path).data.publicUrl
}
