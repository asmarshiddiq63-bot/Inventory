import { useEffect, type ReactNode } from 'react'
import type { Item } from '../lib/types'

export function Modal({ title, onClose, children, footer, wide }: {
  title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])
  return (
    <div className="fixed inset-0 z-50 grid place-items-center overflow-auto bg-[#0a0c24]/70 p-3"
         onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true"
           className={`card max-h-[92vh] w-full overflow-auto !rounded-[20px] !p-5 ${wide ? 'max-w-3xl' : 'max-w-xl'}`}>
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="m-0 text-lg font-extrabold">{title}</h2>
          <button className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Tutup">✕</button>
        </div>
        {children}
        {footer && <div className="mt-4 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  )
}

export function Field({ label, span, children }: { label: string; span?: boolean; children: ReactNode }) {
  return (
    <div className={span ? 'col-span-2' : ''}>
      <label className="lbl">{label}</label>
      {children}
    </div>
  )
}

export const FormGrid = ({ children }: { children: ReactNode }) => <div className="grid grid-cols-2 gap-3">{children}</div>

export function PageHeader({ title, sub, children }: { title: string; sub?: string; children?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2.5">
      <div>
        <h1 className="m-0 text-2xl font-extrabold">{title}</h1>
        {sub && <p className="m-0 mt-1 text-mu">{sub}</p>}
      </div>
      <div className="flex-1" />
      {children}
    </div>
  )
}

export const Empty = ({ children }: { children: ReactNode }) => <div className="p-7 text-center text-mu">{children}</div>

export function Stat({ icon, value, label, tone = 'brand' }: { icon: string; value: ReactNode; label: string; tone?: 'brand' | 'teal' | 'warn' | 'danger' | 'ok' }) {
  return (
    <div className="card flex items-center gap-3">
      <i className={`t-${tone === 'ok' ? 'ok' : tone} grid h-11 w-11 place-items-center rounded-xl text-xl not-italic`}>{icon}</i>
      <div>
        <b className="block text-2xl font-extrabold leading-tight">{value}</b>
        <span className="text-xs text-mu">{label}</span>
      </div>
    </div>
  )
}

export const Thumb = ({ item, size = 38 }: { item: Pick<Item, 'photo_url'>; size?: number }) =>
  item.photo_url ? (
    <img src={item.photo_url} alt="" width={size} height={size} className="inline-block shrink-0 rounded-[9px] object-cover align-middle" style={{ width: size, height: size }} />
  ) : (
    <span className="inline-grid shrink-0 place-items-center rounded-[9px] bg-bg align-middle" style={{ width: size, height: size }}>📦</span>
  )

export function ItemSelect({ items, value, onChange, disabled }: {
  items: Item[]; value: string; onChange: (v: string) => void; disabled?: boolean
}) {
  return (
    <select className="input" value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
      <option value="">— pilih barang —</option>
      {items.map((i) => (
        <option key={i.id} value={i.id}>{i.code} · {i.name}{i.size && i.size !== '-' ? ` (${i.size})` : ''} — stok {i.stock}</option>
      ))}
    </select>
  )
}

export const TYPE_TONE: Record<string, string> = {
  masuk: 't-ok', keluar: 't-warn', koreksi: 't-teal', opname: 't-teal', servis: 't-brand',
  proses: 't-brand', selesai: 't-ok', batal: 't-danger', menunggu: 't-warn', disetujui: 't-ok', ditolak: 't-danger',
  tersedia: 't-ok', dipakai: 't-warn', rusak: 't-danger', servis_unit: 't-brand',
}
