import { useEffect, useRef } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'

const NAV = [
  { to: '/', label: 'Dashboard', ico: '◧', end: true },
  { to: '/master', label: 'Data Barang & Aset', ico: '🗂' },
  { to: '/masuk', label: 'Barang Masuk', ico: '⬇' },
  { to: '/keluar', label: 'Barang Keluar', ico: '⬆' },
  { to: '/servis', label: 'Servis & Maintenance', ico: '🛠' },
  { to: '/opname', label: 'Stock Opname', ico: '☑' },
  { to: '/qr', label: 'QR Code', ico: '▦' },
  { to: '/scan', label: 'Scan QR', ico: '⌖' },
  { to: '/riwayat', label: 'Riwayat', ico: '🕘' },
  { to: '/laporan', label: 'Laporan', ico: '📊' },
  { to: '/pengaturan', label: 'Pengaturan', ico: '⚙', admin: true },
]

const ROLE_LABEL = { administrator: 'Administrator', petugas: 'Petugas Inventory', approver: 'Approver', viewer: 'Viewer' }

export default function Layout() {
  const { profile, role, isAdmin, signOut } = useAuth()
  const qc = useQueryClient()
  const timer = useRef<number>()

  // sinkron realtime antar perangkat
  useEffect(() => {
    const ch = supabase.channel('rdm-realtime')
    for (const table of ['items', 'stock_movements', 'assets', 'service_records', 'stock_opnames']) {
      ch.on('postgres_changes', { event: '*', schema: 'public', table }, () => {
        window.clearTimeout(timer.current)
        timer.current = window.setTimeout(() => qc.invalidateQueries(), 250)
      })
    }
    ch.subscribe()
    return () => { window.clearTimeout(timer.current); supabase.removeChannel(ch) }
  }, [qc])

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <aside className="sticky top-0 z-20 flex w-full shrink-0 gap-1 overflow-x-auto bg-side p-2.5 pt-[max(env(safe-area-inset-top),0.625rem)] text-white md:h-screen md:w-60 md:flex-col md:overflow-y-auto md:p-4">
        <div className="hidden items-center gap-2.5 px-2 pb-4 font-extrabold leading-tight md:flex">
          <i className="grid h-[38px] w-[38px] place-items-center rounded-[11px] bg-gradient-to-br from-brand to-teal not-italic">▣</i>
          <div>REVOLUTEK<small className="block text-[11px] font-medium opacity-60">Dananjaya Mandiri</small></div>
        </div>
        <nav className="flex gap-1 md:flex-col">
          {NAV.filter((n) => !n.admin || isAdmin).map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end}
              className={({ isActive }) =>
                `flex items-center gap-2.5 whitespace-nowrap rounded-xl px-3 py-2.5 font-medium text-[#b9bdea] no-underline hover:bg-white/10 ${isActive ? '!bg-gradient-to-r from-brand to-[#8b6dff] !font-bold !text-white' : ''}`}>
              <span>{n.ico}</span>{n.label}
            </NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2 whitespace-nowrap rounded-xl bg-white/10 px-3 py-2 text-[11px] text-[#b9bdea] md:ml-0 md:mt-auto md:flex-col md:items-start">
          <div>
            <b className="block text-white">{profile?.full_name ?? profile?.email}</b>
            {ROLE_LABEL[role]}
          </div>
          <button className="btn btn-ghost btn-sm" onClick={signOut}>Keluar</button>
        </div>
      </aside>
      <main className="min-w-0 flex-1 p-3.5 md:p-7"><Outlet /></main>
    </div>
  )
}
