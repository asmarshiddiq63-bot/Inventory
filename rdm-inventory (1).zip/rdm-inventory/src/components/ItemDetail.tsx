import { useMemo } from 'react'
import type { Item } from '../lib/types'
import { useAssets, useMovements, useOpnames, useServices } from '../lib/queries'
import { daysUntil, fd, rp } from '../lib/format'
import { Thumb, TYPE_TONE } from './ui'

export default function ItemDetail({ item }: { item: Item }) {
  const { data: mv = [] } = useMovements()
  const { data: sv = [] } = useServices()
  const { data: op = [] } = useOpnames()
  const { data: assets = [] } = useAssets()

  const myAssets = assets.filter((a) => a.item_id === item.id)
  const hist = useMemo(() => {
    const h: { k: string; date: string; tag: string; text: string }[] = []
    mv.filter((m) => m.item_id === item.id).forEach((m) => {
      const s = m.type === 'keluar' ? -m.qty : m.qty
      h.push({ k: m.id, date: m.movement_date, tag: m.type, text: `${s > 0 ? '+' : ''}${s} ${item.unit}${m.party ? ' · ' + m.party : ''}${m.serials?.length ? ' · SN ' + m.serials.join(', ') : ''}` })
    })
    sv.filter((s) => s.item_id === item.id).forEach((s) => h.push({ k: s.id, date: s.start_date, tag: 'servis', text: `${s.issue} · ${s.status}${s.cost ? ' · ' + rp(s.cost) : ''}` }))
    op.filter((o) => o.item_id === item.id).forEach((o) => h.push({ k: o.id, date: o.opname_date, tag: 'opname', text: `Sistem ${o.system_qty} → fisik ${o.physical_qty} (${o.status})` }))
    return h.sort((a, b) => b.date.localeCompare(a.date))
  }, [mv, sv, op, item])

  return (
    <div>
      <div className="mb-3 flex items-center gap-3">
        <Thumb item={item} size={64} />
        <div>
          <b className="text-base">{item.name}</b>
          <div className="text-xs text-mu">{item.code} · {item.category} · {item.size}</div>
          <span className={`tag ${item.kind === 'aset' ? 't-brand' : 't-teal'}`}>{item.kind}</span>
        </div>
      </div>
      <div className="mb-3 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-bg p-2"><b className="block text-lg">{item.stock}</b><span className="text-[11px] text-mu">Stok ({item.unit})</span></div>
        <div className="rounded-xl bg-bg p-2"><b className="block text-lg">{rp(item.price)}</b><span className="text-[11px] text-mu">Harga satuan</span></div>
        <div className="rounded-xl bg-bg p-2"><b className="block text-lg">{item.location ?? '-'}</b><span className="text-[11px] text-mu">Lokasi</span></div>
      </div>
      {item.description && <p className="mt-0 text-mu">{item.description}</p>}

      {myAssets.length > 0 && (
        <>
          <h3 className="mb-2 mt-4 text-sm font-bold">Unit terdaftar (serial number)</h3>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead><tr><th>Serial number</th><th>Status</th><th>Garansi</th></tr></thead>
              <tbody>
                {myAssets.map((a) => {
                  const d = daysUntil(a.warranty_until)
                  return (
                    <tr key={a.id}>
                      <td><b>{a.serial_number}</b></td>
                      <td><span className={`tag ${TYPE_TONE[a.status]}`}>{a.status}</span></td>
                      <td>{a.warranty_until ? (d! < 0 ? <span className="tag t-danger">Habis {fd(a.warranty_until)}</span> : <>{fd(a.warranty_until)}{d! <= 60 && <span className="tag t-warn ml-1">{d} hari lagi</span>}</>) : '-'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      <h3 className="mb-2 mt-4 text-sm font-bold">Riwayat</h3>
      {hist.length === 0 ? <div className="text-mu">Belum ada riwayat.</div> : (
        <div className="ml-1.5 border-l-2 border-bd pl-4">
          {hist.map((h) => (
            <div key={h.k} className="relative mb-3">
              <span className="absolute -left-[23px] top-1 h-2.5 w-2.5 rounded-full bg-brand" />
              <span className={`tag ${TYPE_TONE[h.tag]}`}>{h.tag}</span> <small className="text-mu">{fd(h.date)}</small>
              <div>{h.text}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
