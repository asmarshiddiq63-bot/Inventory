import { createContext, useCallback, useContext, useState, type ReactNode } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Modal } from './ui'

type Kind = 'ok' | 'err'
const ToastCtx = createContext<(m: string, k?: Kind) => void>(() => {})
const ConfirmCtx = createContext<(m: string) => Promise<boolean>>(async () => false)

export const useToast = () => useContext(ToastCtx)
export const useConfirm = () => useContext(ConfirmCtx)

/** jalankan aksi async: toast sukses/gagal + segarkan semua data */
export function useAction() {
  const qc = useQueryClient()
  const toast = useToast()
  return async (fn: () => PromiseLike<unknown>, okMsg: string) => {
    try {
      await fn()
      toast(okMsg)
      await qc.invalidateQueries()
      return true
    } catch (e) {
      toast((e as Error).message || 'Terjadi kesalahan', 'err')
      return false
    }
  }
}

export function FeedbackProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<{ id: number; m: string; k: Kind }[]>([])
  const [cf, setCf] = useState<{ m: string; res: (b: boolean) => void } | null>(null)

  const toast = useCallback((m: string, k: Kind = 'ok') => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, m, k }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), k === 'err' ? 4500 : 2400)
  }, [])
  const confirm = useCallback((m: string) => new Promise<boolean>((res) => setCf({ m, res })), [])
  const close = (b: boolean) => { cf?.res(b); setCf(null) }

  return (
    <ToastCtx.Provider value={toast}>
      <ConfirmCtx.Provider value={confirm}>
        {children}
        <div className="pointer-events-none fixed bottom-5 left-1/2 z-[100] flex -translate-x-1/2 flex-col items-center gap-2" aria-live="polite">
          {toasts.map((t) => (
            <div key={t.id} className={`rounded-xl px-4 py-2.5 font-bold text-white shadow-lg ${t.k === 'err' ? 'bg-danger' : 'bg-[#161a33]'}`}>{t.m}</div>
          ))}
        </div>
        {cf && (
          <Modal title="Konfirmasi" onClose={() => close(false)}
            footer={<><button className="btn btn-ghost" onClick={() => close(false)}>Batal</button><button className="btn" onClick={() => close(true)}>Ya, lanjutkan</button></>}>
            <p className="m-0 leading-relaxed">{cf.m}</p>
          </Modal>
        )}
      </ConfirmCtx.Provider>
    </ToastCtx.Provider>
  )
}
