import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './lib/auth'
import { configured } from './lib/supabase'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Master from './pages/Master'
import Masuk from './pages/Masuk'
import Keluar from './pages/Keluar'
import Servis from './pages/Servis'
import Opname from './pages/Opname'
import QR from './pages/QR'
import Scan from './pages/Scan'
import Riwayat from './pages/Riwayat'
import Laporan from './pages/Laporan'
import Pengaturan from './pages/Pengaturan'

export default function App() {
  const { session, loading, isAdmin } = useAuth()

  if (!configured)
    return (
      <div className="grid min-h-screen place-items-center p-6">
        <div className="card max-w-md">
          <h1 className="mt-0 text-xl font-extrabold">Konfigurasi belum lengkap</h1>
          <p>Isi <code>VITE_SUPABASE_URL</code> dan <code>VITE_SUPABASE_ANON_KEY</code> di file <code>.env</code> (lokal) atau Environment Variables Vercel, lalu build ulang.</p>
        </div>
      </div>
    )
  if (loading) return <div className="grid min-h-screen place-items-center text-mu">Memuat…</div>
  if (!session) return <Login />

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="master" element={<Master />} />
        <Route path="masuk" element={<Masuk />} />
        <Route path="keluar" element={<Keluar />} />
        <Route path="servis" element={<Servis />} />
        <Route path="opname" element={<Opname />} />
        <Route path="qr" element={<QR />} />
        <Route path="scan" element={<Scan />} />
        <Route path="riwayat" element={<Riwayat />} />
        <Route path="laporan" element={<Laporan />} />
        <Route path="pengaturan" element={isAdmin ? <Pengaturan /> : <Navigate to="/" replace />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
