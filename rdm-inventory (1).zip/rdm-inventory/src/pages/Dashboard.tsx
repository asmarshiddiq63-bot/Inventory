import { useMemo } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useAssets, useItems, useMovements, useServices } from '../lib/queries'
import { daysUntil, fd, rp, today } from '../lib/format'
import { Empty, PageHeader, Stat, TYPE_TONE } from '../components/ui'

const COLORS = ['#6c4cff', '#00c2d1', '#ff8a3d', '#ff4d6d', '#18b87a', '#f5c518']

export default function Dashboard() {
  const { data: items = [] } = useItems()
  const { data: mv = [] } = useMovements()
  const { data: sv = [] } = useServices()
  const { data: assets = [] } = useAssets()

  const itemMap = useMemo(() => new Map(items.map((i) => [i.id, i])), [items])
  const val = items.reduce((a, i) => a + i.stock * i.price, 0)
  const units = items.reduce((a, i) => a + i.stock, 0)
  const low = items.filter((i) => i.kind === 'persediaan' && i.stock <= i.min_stock)
  const active = sv.filter((s) => s.status === 'proses')
  const svCost = sv.filter((s) => s.status !== 'batal').reduce((a, s) => a + s.cost, 0)

  const byCat = useMemo(() => {
    const m: Record<string, number> = {}
    items.forEach((i) => { m[i.category] = (m[i.category] ?? 0) + i.stock * i.price })
    return Object.entries(m).map(([name, value]) => ({ name, value })).filter((x) => x.value > 0).sort((a, b) => b.value - a.value)
  }, [items])

  const months = useMemo(() => {
    const [y, m] = today().split('-').map(Number)
    const arr = Array.from({ length: 6 }, (_, k) => {
      const d = new Date(Date.UTC(y, m - 1 - (5 - k), 1))
      return { key: d.toISOString().slice(0, 7), bulan: d.toLocaleDateString('id-ID', { month: 'short', timeZone: 'UTC' }), Masuk: 0, Keluar: 0 }
    })
    mv.forEach((t) => {
      const r = arr.find((x) => x.key === t.movement_date.slice(0, 7))
      if (!r) return
      if (t.type === 'masuk') r.Masuk += t.qty
      if (t.type === 'keluar') r.Keluar += t.qty
    })
    return arr
  }, [mv])

  const alerts = [
    ...assets.filter((a) => a.warranty_until && (daysUntil(a.warranty_until) ?? 999) <= 60).map((a) => {
      const d = daysUntil(a.warranty_until)!
      return { k: 'w' + a.id, text: `${itemMap.get(a.item_id)?.name ?? 'Aset'} · SN ${a.serial_number}`, tag: d < 0 ? 'Garansi habis' : `Garansi ${d} hari lagi`, tone: d < 0 ? 't-danger' : 't-warn' }
    }),
    ...active.filter((s) => s.est_date < today()).map((s) => ({ k: 's' + s.id, text: `${itemMap.get(s.item_id)?.name ?? 'Aset'} · servis`, tag: `Terlambat ${-(daysUntil(s.est_date) ?? 0)} hari`, tone: 't-danger' })),
  ]
  const recent = mv.slice(0, 6)

  return (
    <>
      <PageHeader title="Dashboard Aset" sub="Ringkasan inventory & aset PT Revolutek Dananjaya Mandiri" />
      <div className="grid grid-cols-[repeat(auto-fit,minmax(190px,1fr))] gap-4">
        <div className="card relative col-span-full flex flex-wrap items-center justify-between gap-4 overflow-hidden border-0 bg-gradient-to-r from-[#5b3df5] to-[#00b7d4] text-white">
          <div><span className="opacity-85">Total nilai inventory & aset</span><b className="block text-[clamp(28px,5vw,46px)] font-extrabold tracking-tight">{rp(val)}</b><span className="opacity-85">{items.length} jenis item · {units} unit tercatat</span></div>
          <div className="text-right"><span className="opacity-85">Biaya servis kumulatif</span><b className="block text-2xl font-extrabold">{rp(svCost)}</b></div>
        </div>
        <Stat icon="📦" value={units} label="Total unit" />
        <Stat icon="🏷" value={items.filter((i) => i.kind === 'aset').length} label="Jenis aset" tone="teal" />
        <Stat icon="⚠" value={low.length} label="Stok menipis" tone="danger" />
        <Stat icon="🛠" value={active.length} label="Servis berjalan" tone="warn" />
      </div>

      <div className="mt-4 grid grid-cols-[repeat(auto-fit,minmax(310px,1fr))] gap-4">
        <div className="card">
          <h3 className="mb-3 mt-0 text-[15px]">Nilai per kategori</h3>
          {byCat.length === 0 ? <Empty>Belum ada data</Empty> : (
            <div className="flex flex-wrap items-center gap-4">
              <div className="h-40 w-40">
                <ResponsiveContainer>
                  <PieChart><Pie data={byCat} dataKey="value" innerRadius={42} outerRadius={72} paddingAngle={2}>{byCat.map((_, i) => <Cell key={i} fill={COLORS[i % 6]} />)}</Pie><Tooltip formatter={(v) => rp(Number(v))} /></PieChart>
                </ResponsiveContainer>
              </div>
              <div className="min-w-[140px] flex-1">
                {byCat.map((c, i) => <div key={c.name} className="mb-2 flex justify-between text-xs"><span><b style={{ color: COLORS[i % 6] }}>●</b> {c.name}</span><span>{rp(c.value)}</span></div>)}
              </div>
            </div>
          )}
        </div>
        <div className="card">
          <h3 className="mb-3 mt-0 text-[15px]">Pergerakan barang 6 bulan</h3>
          <div className="h-44">
            <ResponsiveContainer>
              <BarChart data={months}><CartesianGrid strokeDasharray="3 3" stroke="var(--bd)" /><XAxis dataKey="bulan" stroke="var(--mu)" fontSize={12} /><YAxis stroke="var(--mu)" fontSize={12} allowDecimals={false} width={32} /><Tooltip /><Legend /><Bar dataKey="Masuk" fill="#18b87a" radius={[6, 6, 0, 0]} /><Bar dataKey="Keluar" fill="#ff8a3d" radius={[6, 6, 0, 0]} /></BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card">
          <h3 className="mb-3 mt-0 text-[15px]">⚠ Perlu restock</h3>
          {low.length === 0 ? <Empty>Semua stok aman 🎉</Empty> : low.map((i) => (
            <div key={i.id} className="mb-3">
              <div className="mb-1 flex justify-between text-xs"><span>{i.name}</span><b>{i.stock} / min {i.min_stock}</b></div>
              <div className="h-2 rounded-full bg-bg"><div className="h-2 rounded-full bg-danger" style={{ width: `${Math.min(100, (i.stock / Math.max(1, i.min_stock)) * 100)}%` }} /></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h3 className="mb-3 mt-0 text-[15px]">🛡 Garansi & servis perlu perhatian</h3>
          {alerts.length === 0 ? <Empty>Tidak ada peringatan 🎉</Empty> : alerts.map((a) => (
            <div key={a.k} className="flex items-center justify-between gap-2.5 border-b border-bd py-2 last:border-0"><span>{a.text}</span><span className={`tag ${a.tone}`}>{a.tag}</span></div>
          ))}
        </div>
        <div className="card">
          <h3 className="mb-3 mt-0 text-[15px]">Aktivitas terbaru</h3>
          {recent.length === 0 ? <Empty>Belum ada aktivitas</Empty> : recent.map((m) => (
            <div key={m.id} className="flex items-center justify-between gap-2.5 border-b border-bd py-2 last:border-0">
              <span><span className={`tag ${TYPE_TONE[m.type]}`}>{m.type}</span> {itemMap.get(m.item_id)?.name ?? '(dihapus)'}</span>
              <small className="text-mu">{fd(m.movement_date)}</small>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}
