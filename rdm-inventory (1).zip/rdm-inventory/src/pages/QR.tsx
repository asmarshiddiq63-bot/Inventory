import { useRef, useState } from 'react'
import { QRCodeCanvas } from 'qrcode.react'
import { useItems } from '../lib/queries'
import type { Item } from '../lib/types'
import { Empty, Modal, PageHeader } from '../components/ui'

export default function QR() {
  const { data: items = [] } = useItems()
  const [q, setQ] = useState('')
  const [big, setBig] = useState<Item | null>(null)
  const list = items.filter((i) => `${i.name} ${i.code}`.toLowerCase().includes(q.toLowerCase()))

  return (
    <>
      <PageHeader title="Generate QR Code" sub="Tempel label QR pada barang; scan untuk melihat riwayatnya" />
      <input className="input mb-4 max-w-xs" placeholder="Cari nama / kode…" value={q} onChange={(e) => setQ(e.target.value)} />
      {list.length === 0 ? <Empty>Tidak ada barang.</Empty> : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(170px,1fr))] gap-3.5">
          {list.map((i) => (
            <div key={i.id} className="card text-center">
              <div className="mb-2 grid min-h-[150px] place-items-center rounded-xl bg-white p-2.5"><QRCodeCanvas value={i.code} size={128} /></div>
              <b>{i.code}</b>
              <div className="mb-2 mt-0.5 text-xs text-mu">{i.name}</div>
              <button className="btn btn-sm" onClick={() => setBig(i)}>Cetak / Unduh</button>
            </div>
          ))}
        </div>
      )}
      {big && <Label item={big} onClose={() => setBig(null)} />}
    </>
  )
}

function Label({ item, onClose }: { item: Item; onClose: () => void }) {
  const box = useRef<HTMLDivElement>(null)
  const download = () => {
    const c = box.current?.querySelector('canvas')
    if (!c) return
    const a = document.createElement('a')
    a.href = c.toDataURL('image/png')
    a.download = `${item.code}.png`
    a.click()
  }
  return (
    <Modal title="Label QR" onClose={onClose}>
      <div id="qrp" className="text-center">
        <div ref={box} className="inline-grid rounded-xl bg-white p-3.5"><QRCodeCanvas value={item.code} size={220} marginSize={1} /></div>
        <h3 className="mb-0.5 mt-2.5">{item.name}</h3>
        <div>{item.code}{item.size && item.size !== '-' ? ` · ${item.size}` : ''}</div>
        <small>PT Revolutek Dananjaya Mandiri</small>
      </div>
      <div className="mt-3.5 flex justify-center gap-2">
        <button className="btn" onClick={() => window.print()}>Cetak</button>
        <button className="btn btn-ghost" onClick={download}>Unduh PNG</button>
      </div>
    </Modal>
  )
}
