import { useEffect, useRef, useState } from 'react'
import { Html5Qrcode } from 'html5-qrcode'
import { useItems } from '../lib/queries'
import type { Item } from '../lib/types'
import ItemDetail from '../components/ItemDetail'
import { PageHeader } from '../components/ui'

export default function Scan() {
  const { data: items = [] } = useItems()
  const itemsRef = useRef<Item[]>([])
  itemsRef.current = items
  const scanner = useRef<Html5Qrcode | null>(null)
  const [on, setOn] = useState(false)
  const [msg, setMsg] = useState('')
  const [found, setFound] = useState<Item | null>(null)
  const [manual, setManual] = useState('')

  const lookup = (code: string) => {
    const it = itemsRef.current.find((i) => i.code.toUpperCase() === code.trim().toUpperCase())
    if (it) { setFound(it); setMsg('') } else { setFound(null); setMsg(`Kode "${code}" tidak ditemukan`) }
    return !!it
  }

  async function stop() {
    const s = scanner.current
    if (s?.isScanning) { try { await s.stop(); s.clear() } catch { /* abaikan */ } }
    setOn(false)
  }

  async function start() {
    setMsg(''); setFound(null)
    try {
      const s = new Html5Qrcode('reader')
      scanner.current = s
      await s.start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 220, height: 220 } }, (txt) => { if (lookup(txt)) void stop() }, () => {})
      setOn(true)
    } catch {
      setMsg('Kamera tidak bisa dibuka. Izinkan akses kamera atau masukkan kode manual.')
    }
  }

  useEffect(() => () => { const s = scanner.current; if (s?.isScanning) s.stop().then(() => s.clear()).catch(() => {}) }, [])

  return (
    <>
      <PageHeader title="Scan QR" sub="Arahkan kamera ke label QR untuk melihat stok & riwayat" />
      <div className="card mb-4">
        <div id="reader" className="mx-auto mb-3 w-full max-w-[420px] overflow-hidden rounded-2xl" />
        <div className="flex flex-wrap justify-center gap-2">
          {!on ? <button className="btn" onClick={start}>▶ Mulai scan</button> : <button className="btn btn-danger" onClick={stop}>■ Berhenti</button>}
        </div>
        <form className="mx-auto mt-3 flex max-w-[420px] gap-2" onSubmit={(e) => { e.preventDefault(); lookup(manual) }}>
          <input className="input" placeholder="Atau ketik kode, mis. RDM-0001" value={manual} onChange={(e) => setManual(e.target.value)} />
          <button className="btn btn-ghost">Cari</button>
        </form>
        {msg && <p className="mb-0 mt-3 text-center font-bold text-danger" role="alert">{msg}</p>}
      </div>
      {found && <div className="card"><ItemDetail item={found} /></div>}
    </>
  )
}
