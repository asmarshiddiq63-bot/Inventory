import { useMemo, useState, type ChangeEvent } from 'react'
import { useItems } from '../lib/queries'
import { useAuth } from '../lib/auth'
import { db, uploadPhoto } from '../lib/api'
import { supabase } from '../lib/supabase'
import { rp } from '../lib/format'
import type { Item, Kind } from '../lib/types'
import { useAction, useConfirm, useToast } from '../components/Toast'
import { Empty, Field, FormGrid, Modal, PageHeader, Thumb } from '../components/ui'
import ItemDetail from '../components/ItemDetail'

export default function Master() {
  const { data: items = [], isLoading } = useItems()
  const { canWrite, isAdmin } = useAuth()
  const run = useAction()
  const confirm = useConfirm()
  const [q, setQ] = useState('')
  const [kind, setKind] = useState('')
  const [st, setSt] = useState('')
  const [edit, setEdit] = useState<Item | 'new' | null>(null)
  const [detail, setDetail] = useState<Item | null>(null)

  const cats = useMemo(() => [...new Set(items.map((i) => i.category))].sort(), [items])
  const list = items.filter((i) => {
    const hay = `${i.name} ${i.code} ${i.category} ${i.location ?? ''}`.toLowerCase()
    if (!hay.includes(q.toLowerCase())) return false
    if (kind && i.kind !== kind) return false
    if (st === 'low') return i.kind === 'persediaan' && i.stock <= i.min_stock
    if (st === 'out') return i.stock <= 0
    if (st === 'ok') return i.stock > i.min_stock
    return true
  })

  async function remove(i: Item) {
    if (!(await confirm(`Nonaktifkan "${i.name}"? Riwayat transaksi tetap tersimpan.`))) return
    await run(() => db(supabase.from('items').update({ is_active: false }).eq('id', i.id)), 'Master data dinonaktifkan')
  }

  return (
    <>
      <PageHeader title="Data Barang & Aset" sub="Data induk barang & aset lengkap dengan foto dan stok terkini">
        {canWrite && <button className="btn" onClick={() => setEdit('new')}>+ Tambah master</button>}
      </PageHeader>
      <div className="mb-3 flex flex-wrap items-center gap-2.5">
        <input className="input max-w-xs" placeholder="Cari nama, kode, kategori, lokasi…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input max-w-[170px]" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="">Semua jenis</option><option value="persediaan">Persediaan</option><option value="aset">Aset</option>
        </select>
        <span className="text-mu">{list.length} item</span>
      </div>
      <div className="mb-4 flex flex-wrap gap-2">
        {[['', 'Semua'], ['low', '⚠ Menipis'], ['out', 'Habis'], ['ok', 'Aman']].map(([v, l]) => (
          <button key={v} className={`btn btn-sm ${st === v ? '' : 'btn-ghost'}`} onClick={() => setSt(v)}>{l}</button>
        ))}
      </div>

      {isLoading ? <Empty>Memuat…</Empty> : list.length === 0 ? <Empty>Tidak ada data.</Empty> : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(230px,1fr))] gap-4">
          {list.map((i) => {
            const low = i.kind === 'persediaan' && i.stock <= i.min_stock
            return (
              <div key={i.id} className="card overflow-hidden !p-0">
                <button className="relative grid h-40 w-full cursor-pointer place-items-center border-0 bg-bg text-5xl" onClick={() => setDetail(i)} aria-label={`Detail ${i.name}`}>
                  {i.photo_url ? <img src={i.photo_url} alt="" className="h-full w-full object-cover" /> : '📦'}
                  <span className={`tag absolute left-2.5 top-2.5 bg-card text-tx`}>{i.kind}</span>
                </button>
                <div className="p-3.5">
                  <b>{i.name}</b>
                  <div className="text-xs text-mu">{i.code} · {i.category} · {i.size}</div>
                  <div className="my-2 flex items-center justify-between">
                    <span className={`tag ${low ? 't-danger' : 't-ok'}`}>Stok {i.stock} {i.unit}</span>
                    <b>{rp(i.price)}</b>
                  </div>
                  <div className="text-xs text-mu">📍 {i.location}</div>
                  <div className="mt-2.5 flex gap-1.5">
                    <button className="btn btn-ghost btn-sm" onClick={() => setDetail(i)}>Detail</button>
                    {canWrite && <button className="btn btn-ghost btn-sm" onClick={() => setEdit(i)}>Edit</button>}
                    {isAdmin && <button className="btn btn-danger btn-sm" onClick={() => remove(i)}>Hapus</button>}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {detail && <Modal title="Detail barang / aset" wide onClose={() => setDetail(null)}><ItemDetail item={detail} /></Modal>}
      {edit && <ItemForm item={edit === 'new' ? undefined : edit} cats={cats} onClose={() => setEdit(null)} />}
    </>
  )
}

function ItemForm({ item, cats, onClose }: { item?: Item; cats: string[]; onClose: () => void }) {
  const run = useAction()
  const toast = useToast()
  const [f, setF] = useState({
    name: item?.name ?? '', code: item?.code ?? '', category: item?.category ?? '', kind: (item?.kind ?? 'persediaan') as Kind,
    size: item?.size ?? '', unit: item?.unit ?? 'unit', price: String(item?.price ?? ''), min_stock: String(item?.min_stock ?? 5),
    location: item?.location ?? '', opening_qty: '0', description: item?.description ?? '',
  })
  const [photo, setPhoto] = useState(item?.photo_url ?? '')
  const [busy, setBusy] = useState(false)
  const set = (k: keyof typeof f) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value })

  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    try { setBusy(true); setPhoto(await uploadPhoto(file)) } catch (err) { toast((err as Error).message, 'err') } finally { setBusy(false) }
  }

  async function save() {
    if (!f.name.trim()) return toast('Nama wajib diisi', 'err')
    const price = Number(f.price || 0)
    if (isNaN(price) || price < 0) return toast('Harga tidak valid', 'err')
    const row = {
      name: f.name.trim(), category: f.category.trim() || 'Umum', kind: f.kind, size: f.size.trim() || '-', unit: f.unit.trim() || 'unit',
      price, min_stock: Math.max(0, Math.floor(Number(f.min_stock) || 0)), location: f.location.trim() || '-',
      description: f.description.trim() || null, photo_url: photo || null,
    }
    const ok = await run(async () => {
      if (item) await db(supabase.from('items').update(row).eq('id', item.id))
      else await db(supabase.from('items').insert({ ...row, ...(f.code.trim() ? { code: f.code.trim() } : {}), opening_qty: Math.max(0, Math.floor(Number(f.opening_qty) || 0)) }))
    }, 'Master data tersimpan')
    if (ok) onClose()
  }

  return (
    <Modal title={item ? 'Edit Master Data' : 'Tambah Master Data'} onClose={onClose}
      footer={<><button className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn" disabled={busy} onClick={save}>Simpan</button></>}>
      <FormGrid>
        <Field label="Foto barang / aset" span>
          <div className="grid h-36 place-items-center overflow-hidden rounded-xl border border-dashed border-bd bg-bg text-4xl">
            {photo ? <img src={photo} alt="" className="h-full w-full object-cover" /> : '📦'}
          </div>
          <div className="mt-2 flex gap-2">
            <label className="btn btn-ghost btn-sm m-0 cursor-pointer">{busy ? 'Mengunggah…' : 'Pilih / ambil foto'}<input type="file" accept="image/*" className="hidden" onChange={onFile} /></label>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setPhoto('')}>Hapus foto</button>
          </div>
        </Field>
        <Field label="Nama" span><input className="input" value={f.name} onChange={set('name')} /></Field>
        <Field label="Kode barang / aset"><input className="input" value={f.code} onChange={set('code')} disabled={!!item} placeholder="Kosongkan = otomatis" /></Field>
        <Field label="Jenis">
          <select className="input" value={f.kind} onChange={set('kind')}><option value="persediaan">Persediaan (habis pakai)</option><option value="aset">Aset (tetap)</option></select>
        </Field>
        <Field label="Kategori">
          <input className="input" list="cats" value={f.category} onChange={set('category')} />
          <datalist id="cats">{cats.map((c) => <option key={c} value={c} />)}</datalist>
        </Field>
        <Field label="Size / ukuran"><input className="input" value={f.size} onChange={set('size')} placeholder="Tiap size = kode sendiri" /></Field>
        <Field label="Satuan"><input className="input" value={f.unit} onChange={set('unit')} /></Field>
        <Field label="Harga satuan (Rp)"><input className="input" type="number" min={0} value={f.price} onChange={set('price')} /></Field>
        <Field label="Stok minimum"><input className="input" type="number" min={0} value={f.min_stock} onChange={set('min_stock')} /></Field>
        <Field label="Lokasi simpan"><input className="input" value={f.location} onChange={set('location')} /></Field>
        {item ? <Field label="Stok saat ini"><input className="input" value={item.stock} disabled /></Field>
              : <Field label="Stok awal"><input className="input" type="number" min={0} value={f.opening_qty} onChange={set('opening_qty')} /></Field>}
        <Field label="Deskripsi" span><textarea className="input" rows={2} value={f.description} onChange={set('description')} /></Field>
      </FormGrid>
    </Modal>
  )
}
