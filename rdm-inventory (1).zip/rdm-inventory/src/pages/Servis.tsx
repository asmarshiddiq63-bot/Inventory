import { useMemo, useState } from 'react'
import { useAssets, useItems, useServices } from '../lib/queries'
import { useAuth } from '../lib/auth'
import { db } from '../lib/api'
import { supabase } from '../lib/supabase'
import { fd, rp, today } from '../lib/format'
import type { ServiceRec } from '../lib/types'
import { useAction, useConfirm, useToast } from '../components/Toast'
import { Empty, Field, FormGrid, ItemSelect, Modal, PageHeader, Stat, TYPE_TONE } from '../components/ui'

export default function Servis() {
  const { data: items = [] } = useItems()
  const { data: sv = [] } = useServices()
  const { canWrite, isAdmin } = useAuth()
  const run = useAction()
  const confirm = useConfirm()
  const [form, setForm] = useState<ServiceRec | 'new' | null>(null)
  const map = useMemo(() => new Map(items.map((i) => [i.id, i])), [items])
  const total = sv.filter((s) => s.status !== 'batal').reduce((a, s) => a + s.cost, 0)

  async function del(id: string) {
    if (await confirm('Hapus data servis ini?')) await run(() => db(supabase.from('service_records').delete().eq('id', id)), 'Dihapus')
  }

  return (
    <>
      <PageHeader title="Servis & Maintenance" sub="Biaya & estimasi tanggal selesai servis">
        {canWrite && <button className="btn" onClick={() => setForm('new')}>+ Servis baru</button>}
      </PageHeader>
      <div className="mb-4 grid grid-cols-[repeat(auto-fit,minmax(190px,1fr))] gap-4">
        <Stat icon="🛠" value={sv.filter((s) => s.status === 'proses').length} label="Sedang diservis" tone="warn" />
        <Stat icon="✔" value={sv.filter((s) => s.status === 'selesai').length} label="Selesai" tone="ok" />
        <Stat icon="💰" value={<span className="text-xl">{rp(total)}</span>} label="Total biaya servis" />
      </div>
      <div className="card overflow-x-auto">
        {sv.length === 0 ? <Empty>Belum ada data servis.</Empty> : (
          <table className="tbl">
            <thead><tr><th>Aset</th><th>Kerusakan</th><th>Vendor</th><th>Biaya</th><th>Masuk</th><th>Estimasi selesai</th><th>Status</th><th /></tr></thead>
            <tbody>
              {sv.map((s) => {
                const late = s.status === 'proses' && s.est_date < today()
                const i = map.get(s.item_id)
                return (
                  <tr key={s.id}>
                    <td>{i?.name ?? '(dinonaktifkan)'}<br /><small className="text-mu">{i?.code}{s.serial_number ? ` · SN: ${s.serial_number}` : ''}</small></td>
                    <td>{s.issue}</td><td>{s.vendor ?? '-'}</td><td>{rp(s.cost)}</td><td>{fd(s.start_date)}</td>
                    <td>{fd(s.est_date)}{late && <span className="tag t-danger ml-1">terlambat</span>}</td>
                    <td><span className={`tag ${TYPE_TONE[s.status]}`}>{s.status}</span></td>
                    <td className="whitespace-nowrap">
                      {canWrite && <button className="btn btn-ghost btn-sm" onClick={() => setForm(s)}>Edit</button>}{' '}
                      {isAdmin && <button className="btn btn-danger btn-sm" onClick={() => del(s.id)}>Hapus</button>}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
      {form && <ServisForm rec={form === 'new' ? undefined : form} onClose={() => setForm(null)} />}
    </>
  )
}

function ServisForm({ rec, onClose }: { rec?: ServiceRec; onClose: () => void }) {
  const { data: items = [] } = useItems()
  const { data: assets = [] } = useAssets()
  const run = useAction()
  const toast = useToast()
  const [f, setF] = useState({ item: rec?.item_id ?? '', sn: rec?.serial_number ?? '', issue: rec?.issue ?? '', vendor: rec?.vendor ?? '', cost: String(rec?.cost ?? ''), start: rec?.start_date ?? today(), est: rec?.est_date ?? today(), status: rec?.status ?? 'proses' })
  const units = assets.filter((a) => a.item_id === f.item)

  async function save() {
    if (!f.item) return toast('Pilih barang / aset', 'err')
    if (!f.issue.trim()) return toast('Isi keluhan', 'err')
    if (f.est < f.start) return toast('Estimasi selesai tidak boleh sebelum tanggal masuk', 'err')
    const asset = units.find((a) => a.serial_number === f.sn.trim().toUpperCase())
    const row = { item_id: f.item, asset_id: asset?.id ?? null, serial_number: f.sn.trim().toUpperCase() || null, issue: f.issue.trim(), vendor: f.vendor.trim() || null, cost: Math.max(0, Number(f.cost) || 0), start_date: f.start, est_date: f.est, status: f.status }
    const ok = await run(() => db(rec ? supabase.from('service_records').update(row).eq('id', rec.id) : supabase.from('service_records').insert(row)), 'Servis tersimpan')
    if (ok) onClose()
  }

  return (
    <Modal title={rec ? 'Edit Servis' : 'Form Servis'} onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn" onClick={save}>Simpan</button></>}>
      <FormGrid>
        <Field label="Barang / aset" span><ItemSelect items={items} value={f.item} onChange={(v) => setF({ ...f, item: v, sn: '' })} disabled={!!rec} /></Field>
        <Field label="Serial number unit" span>
          <input className="input" list="sn-list" value={f.sn} onChange={(e) => setF({ ...f, sn: e.target.value })} placeholder="Opsional" />
          <datalist id="sn-list">{units.map((u) => <option key={u.id} value={u.serial_number} />)}</datalist>
        </Field>
        <Field label="Keluhan / kerusakan" span><input className="input" value={f.issue} onChange={(e) => setF({ ...f, issue: e.target.value })} /></Field>
        <Field label="Vendor / teknisi"><input className="input" value={f.vendor} onChange={(e) => setF({ ...f, vendor: e.target.value })} /></Field>
        <Field label="Biaya servis (Rp)"><input className="input" type="number" min={0} value={f.cost} onChange={(e) => setF({ ...f, cost: e.target.value })} /></Field>
        <Field label="Tanggal masuk servis"><input className="input" type="date" value={f.start} onChange={(e) => setF({ ...f, start: e.target.value })} /></Field>
        <Field label="Estimasi selesai"><input className="input" type="date" value={f.est} onChange={(e) => setF({ ...f, est: e.target.value })} /></Field>
        <Field label="Status" span>
          <select className="input" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as ServiceRec['status'] })}><option value="proses">Proses</option><option value="selesai">Selesai</option><option value="batal">Batal</option></select>
        </Field>
      </FormGrid>
    </Modal>
  )
}
