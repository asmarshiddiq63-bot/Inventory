import { useMemo, useState } from 'react'
import { useItems, useMovements } from '../lib/queries'
import { useAuth } from '../lib/auth'
import { rpc } from '../lib/api'
import { fd, rp, today, toks } from '../lib/format'
import { useAction, useConfirm, useToast } from '../components/Toast'
import { Empty, Field, FormGrid, ItemSelect, Modal, PageHeader } from '../components/ui'

export default function Masuk() {
  const { data: items = [] } = useItems()
  const { data: mv = [] } = useMovements()
  const { canWrite, isAdmin } = useAuth()
  const run = useAction()
  const confirm = useConfirm()
  const [open, setOpen] = useState(false)
  const map = useMemo(() => new Map(items.map((i) => [i.id, i])), [items])
  const rows = mv.filter((m) => m.type === 'masuk')

  async function del(id: string) {
    if (await confirm('Hapus transaksi ini? Stok akan dikurangi.')) await run(() => rpc('rpc_delete_movement', { p_id: id }), 'Transaksi dihapus')
  }

  return (
    <>
      <PageHeader title="Barang Masuk" sub="Catat penerimaan barang & aset baru">
        {canWrite && <button className="btn" onClick={() => setOpen(true)}>+ Barang masuk</button>}
      </PageHeader>
      <div className="card overflow-x-auto">
        {rows.length === 0 ? <Empty>Belum ada barang masuk.</Empty> : (
          <table className="tbl">
            <thead><tr><th>Tanggal</th><th>Barang</th><th>Qty</th><th>Harga satuan</th><th>Total</th><th>Supplier</th><th /></tr></thead>
            <tbody>
              {rows.map((t) => {
                const i = map.get(t.item_id)
                return (
                  <tr key={t.id}>
                    <td>{fd(t.movement_date)}</td>
                    <td>{i?.name ?? '(dinonaktifkan)'}<br /><small className="text-mu">{i?.code}{i?.size && i.size !== '-' ? ` · ${i.size}` : ''}</small>{t.serials?.length ? <><br /><small>SN: {t.serials.join(', ')}</small></> : null}</td>
                    <td><b>{t.qty}</b></td>
                    <td>{rp(t.unit_price)}</td>
                    <td><b>{rp(t.qty * (t.unit_price ?? 0))}</b></td>
                    <td>{t.party ?? '-'}</td>
                    <td>{isAdmin && <button className="btn btn-danger btn-sm" onClick={() => del(t.id)}>Hapus</button>}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
      {open && <MasukForm onClose={() => setOpen(false)} />}
    </>
  )
}

function MasukForm({ onClose }: { onClose: () => void }) {
  const { data: items = [] } = useItems()
  const run = useAction()
  const toast = useToast()
  const [f, setF] = useState({ item: '', qty: '1', price: '', party: '', date: today(), sn: '', warranty: '', note: '' })
  const sel = items.find((i) => i.id === f.item)

  async function save() {
    const qty = Math.floor(Number(f.qty))
    if (!sel) return toast('Pilih barang', 'err')
    if (!(qty > 0)) return toast('Jumlah harus lebih dari 0', 'err')
    if (toks(f.sn).length > qty) return toast('Jumlah serial number melebihi jumlah masuk', 'err')
    const ok = await run(() => rpc('rpc_stock_in', {
      p_item: sel.id, p_qty: qty, p_date: f.date || today(), p_party: f.party, p_price: Number(f.price) || sel.price,
      p_note: f.note, p_serials: toks(f.sn), p_warranty: f.warranty || null,
    }), 'Barang masuk tersimpan')
    if (ok) onClose()
  }

  return (
    <Modal title="Barang Masuk" onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn" onClick={save}>Simpan</button></>}>
      <FormGrid>
        <Field label="Barang" span>
          <ItemSelect items={items} value={f.item} onChange={(v) => setF({ ...f, item: v, price: String(items.find((i) => i.id === v)?.price ?? '') })} />
          <small className="text-mu">Barang belum ada? Tambahkan dulu di menu Data Barang & Aset.</small>
        </Field>
        <Field label="Jumlah masuk"><input className="input" type="number" min={1} value={f.qty} onChange={(e) => setF({ ...f, qty: e.target.value })} /></Field>
        <Field label="Harga satuan (Rp)"><input className="input" type="number" min={0} value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></Field>
        <Field label="Supplier"><input className="input" value={f.party} onChange={(e) => setF({ ...f, party: e.target.value })} /></Field>
        <Field label="Tanggal"><input className="input" type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
        <Field label="Serial number (elektronik / mesin)" span><textarea className="input" rows={2} value={f.sn} onChange={(e) => setF({ ...f, sn: e.target.value })} placeholder="Banyak unit? pisahkan dengan koma atau baris baru" /></Field>
        <Field label="Garansi sampai (untuk unit ber-SN)"><input className="input" type="date" value={f.warranty} onChange={(e) => setF({ ...f, warranty: e.target.value })} /></Field>
        <Field label="Catatan"><input className="input" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field>
      </FormGrid>
    </Modal>
  )
}
