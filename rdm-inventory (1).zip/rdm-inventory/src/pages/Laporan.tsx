import { useMemo, useState } from 'react'
import * as XLSX from 'xlsx'
import { useAssets, useItems, useMovements, useOpnames, useServices } from '../lib/queries'
import { fd, rp, today } from '../lib/format'
import { PageHeader, Stat } from '../components/ui'

export default function Laporan() {
  const { data: items = [] } = useItems()
  const { data: mv = [] } = useMovements()
  const { data: sv = [] } = useServices()
  const { data: op = [] } = useOpnames()
  const { data: assets = [] } = useAssets()
  const [from, setFrom] = useState(today().slice(0, 8) + '01')
  const [to, setTo] = useState(today())

  const im = useMemo(() => new Map(items.map((i) => [i.id, i])), [items])
  const inRange = (d: string) => d >= from && d <= to
  const masuk = mv.filter((m) => m.type === 'masuk' && inRange(m.movement_date))
  const keluar = mv.filter((m) => m.type === 'keluar' && inRange(m.movement_date))
  const servis = sv.filter((s) => inRange(s.start_date))
  const nilaiMasuk = masuk.reduce((a, m) => a + m.qty * (m.unit_price ?? 0), 0)
  const nilaiStok = items.reduce((a, i) => a + i.stock * i.price, 0)
  const nm = (id: string) => im.get(id)?.name ?? '(dinonaktifkan)'
  const cd = (id: string) => im.get(id)?.code ?? ''

  const sheets: Record<string, () => object[]> = {
    'Barang & Aset': () => items.map((i) => ({ Kode: i.code, Nama: i.name, Jenis: i.kind, Kategori: i.category, Size: i.size, Satuan: i.unit, 'Harga satuan': i.price, Stok: i.stock, 'Stok minimum': i.min_stock, 'Nilai stok': i.stock * i.price, Lokasi: i.location })),
    'Unit (SN)': () => assets.map((a) => ({ Kode: cd(a.item_id), Barang: nm(a.item_id), 'Serial number': a.serial_number, Status: a.status, 'Garansi sampai': a.warranty_until ?? '', Lokasi: a.location ?? '' })),
    'Barang Masuk': () => masuk.map((m) => ({ Tanggal: m.movement_date, Kode: cd(m.item_id), Barang: nm(m.item_id), Qty: m.qty, 'Harga satuan': m.unit_price ?? 0, Total: m.qty * (m.unit_price ?? 0), Supplier: m.party ?? '', SN: m.serials?.join(', ') ?? '', Catatan: m.note ?? '' })),
    'Barang Keluar': () => keluar.map((m) => ({ Tanggal: m.movement_date, Kode: cd(m.item_id), Barang: nm(m.item_id), Qty: m.qty, Tujuan: m.party ?? '', SN: m.serials?.join(', ') ?? '', Catatan: m.note ?? '' })),
    'Servis': () => servis.map((s) => ({ Kode: cd(s.item_id), Aset: nm(s.item_id), SN: s.serial_number ?? '', Kerusakan: s.issue, Vendor: s.vendor ?? '', Biaya: s.cost, Masuk: s.start_date, 'Estimasi selesai': s.est_date, Status: s.status })),
    'Opname': () => op.filter((o) => inRange(o.opname_date)).map((o) => ({ Tanggal: o.opname_date, Kode: cd(o.item_id), Barang: nm(o.item_id), Sistem: o.system_qty, Fisik: o.physical_qty, Selisih: o.diff, Status: o.status })),
  }

  function exportSheets(names: string[], file: string) {
    const wb = XLSX.utils.book_new()
    names.forEach((n) => {
      const data = sheets[n]()
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.length ? data : [{ Info: 'Tidak ada data' }]), n.slice(0, 31))
    })
    XLSX.writeFile(wb, `${file}-${today()}.xlsx`)
  }

  const low = items.filter((i) => i.kind === 'persediaan' && i.stock <= i.min_stock)

  return (
    <>
      <PageHeader title="Laporan" sub="Ringkasan periode dan ekspor ke Excel">
        <button className="btn" onClick={() => exportSheets(Object.keys(sheets), 'RDM-Inventory-Lengkap')}>⬇ Ekspor semua (.xlsx)</button>
      </PageHeader>
      <div className="mb-4 flex flex-wrap items-end gap-3">
        <div><label className="lbl">Dari</label><input className="input" type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div><label className="lbl">Sampai</label><input className="input" type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
      </div>
      <div className="mb-4 grid grid-cols-[repeat(auto-fit,minmax(200px,1fr))] gap-4">
        <Stat icon="⬇" value={masuk.reduce((a, m) => a + m.qty, 0)} label={`Unit masuk · ${rp(nilaiMasuk)}`} tone="ok" />
        <Stat icon="⬆" value={keluar.reduce((a, m) => a + m.qty, 0)} label="Unit keluar" tone="warn" />
        <Stat icon="🛠" value={<span className="text-xl">{rp(servis.filter((s) => s.status !== 'batal').reduce((a, s) => a + s.cost, 0))}</span>} label="Biaya servis periode" />
        <Stat icon="💰" value={<span className="text-xl">{rp(nilaiStok)}</span>} label="Nilai stok saat ini" tone="teal" />
      </div>
      <div className="card mb-4">
        <h3 className="mb-3 mt-0 text-[15px]">Ekspor per laporan</h3>
        <div className="flex flex-wrap gap-2">
          {Object.keys(sheets).map((n) => <button key={n} className="btn btn-ghost" onClick={() => exportSheets([n], 'RDM-' + n.replace(/\W+/g, '-'))}>📊 {n}</button>)}
        </div>
        <p className="mb-0 mt-3 text-xs text-mu">Barang Masuk, Keluar, Servis, dan Opname mengikuti rentang tanggal di atas.</p>
      </div>
      <div className="card overflow-x-auto">
        <h3 className="mb-3 mt-0 text-[15px]">Stok menipis ({low.length})</h3>
        <table className="tbl">
          <thead><tr><th>Kode</th><th>Barang</th><th>Stok</th><th>Minimum</th><th>Lokasi</th></tr></thead>
          <tbody>{low.map((i) => <tr key={i.id}><td>{i.code}</td><td>{i.name}</td><td><span className="tag t-danger">{i.stock}</span></td><td>{i.min_stock}</td><td>{i.location}</td></tr>)}</tbody>
        </table>
        {low.length === 0 && <div className="p-4 text-center text-mu">Semua stok aman 🎉 · per {fd(today())}</div>}
      </div>
    </>
  )
}
