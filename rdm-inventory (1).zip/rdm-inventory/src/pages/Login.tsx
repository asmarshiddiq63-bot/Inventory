import { useState, type FormEvent } from 'react'
import { useAuth } from '../lib/auth'

export default function Login() {
  const { signIn, signUp } = useAuth()
  const [mode, setMode] = useState<'in' | 'up'>('in')
  const [f, setF] = useState({ name: '', email: '', password: '' })
  const [err, setErr] = useState('')
  const [info, setInfo] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault()
    setErr(''); setInfo(''); setBusy(true)
    const m = mode === 'in' ? await signIn(f.email, f.password) : await signUp(f.email, f.password, f.name || f.email.split('@')[0])
    setBusy(false)
    if (m) setErr(m)
    else if (mode === 'up') setInfo('Akun dibuat. Jika diminta, konfirmasi email Anda. Akun baru berperan Viewer — minta administrator menaikkan hak akses.')
  }

  return (
    <div className="grid min-h-screen place-items-center bg-gradient-to-br from-side to-[#2a2478] p-4">
      <form onSubmit={submit} className="card w-full max-w-sm !p-6">
        <div className="mb-4 flex items-center gap-2.5 font-extrabold leading-tight">
          <i className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand to-teal not-italic text-white">▣</i>
          <div>REVOLUTEK<small className="block text-[11px] font-medium text-mu">RDM Inventory & Aset</small></div>
        </div>
        <div className="grid gap-3">
          {mode === 'up' && <div><label className="lbl">Nama lengkap</label><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>}
          <div><label className="lbl">Email</label><input className="input" type="email" required autoComplete="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
          <div><label className="lbl">Kata sandi</label><input className="input" type="password" required minLength={6} autoComplete={mode === 'in' ? 'current-password' : 'new-password'} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
          {err && <div className="t-danger rounded-xl px-3 py-2 font-bold" role="alert">{err}</div>}
          {info && <div className="t-ok rounded-xl px-3 py-2 font-bold">{info}</div>}
          <button className="btn" disabled={busy}>{busy ? 'Memproses…' : mode === 'in' ? 'Masuk' : 'Daftar'}</button>
          <button type="button" className="btn btn-ghost" onClick={() => { setMode(mode === 'in' ? 'up' : 'in'); setErr(''); setInfo('') }}>
            {mode === 'in' ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk'}
          </button>
        </div>
      </form>
    </div>
  )
}
