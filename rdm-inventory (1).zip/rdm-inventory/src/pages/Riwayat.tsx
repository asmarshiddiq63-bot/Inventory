import { useMemo, useState } from 'react'
import { useItems, useMovements, useOpnames, useProfiles, useServices } from '../lib/queries'
import { fd, fdt } from '../lib/format'
import { Empty, PageHeader, TYPE_TONE } from '../components/ui'

interface Row { k: string; date: string; ts: string; type: string; item: string; code: string; detail: string; by: string | null }

export default function Riwayat() {
  const { data: items = [] } = useItems()
  const { data: mv = [] } = useMovements()
  const { data: sv = [] } = useServices()
  const { data: op = [] } = useOpnames()
  const { data: profiles = [] } = useProfiles()
  const [q, setQ] = useState('')
  const [type, setType] = useState('')
  const [limit, setLimit] = useState(100)

  const rows = useMemo(() => {
    const im = new Map(items.map((i) => [i.id, i]))
    const pm = new Map(profiles.map((p) => [p.id, p.full_name ?? p.email]))
    const nm = (id: string) => im.get(id)?.name ?? '(dinonaktifkan)'
    const cd = (id: string) => im.get(id)?.code ?? ''
    const out: Row[] = []
    mv.forEach((m) => out.push({ k: 'm' + m.id, date: m.movement_date, ts: m.created_at, type: m.type, item: nm(m.item_id), code: cd(m.item_id), detail: `${m.type === 'keluar' ? '-' : m.qty > 0 ? '+' : ''}${m.qty}${m.party ? ' · ' + m.party : ''}${m.serials?.length ? ' · SN ' + m.serials.join(', ') : ''}${m.note ? ' · ' + m.note : ''}`, by: m.created_by ? pm.get(m.created_by) ?? null : null }))
    sv.forEach((s) => out.push({ k: 's' + s.id, date: s.start_date, ts: s.created_at, type: 'servis', item: nm(s.item_id), code: cd(s.item_id), detail: `${s.issue} · ${s.status}${s.vendor ? ' · ' + s.vendor : ''}`, by: s.created_by ? pm.get(s.created_by) ?? null : null }))
    op.forEach((o) => out.push({ k: 'o' + o.id, date: o.opname_date, ts: o.created_at, type: 'opname', item: nm(o.item_id), code: cd(o.item_id), detail: `Sistem ${o.system_qty} → fisik ${o.physical_qty} · ${o.status}`, by: o.created_by ? pm.get(o.created_by) ?? null : null }))
    return out.sort((a, b) => b.date.localeCompare(a.date) || b.ts.localeCompare(a.ts))
  }, [items, mv, sv, op, profiles])

  const list = rows.filter((r) => (!type || r.type === type) && `${r.item} ${r.code} ${r.detail}`.toLowerCase().includes(q.toLowerCase()))

  return (
    <>
      <PageHeader title="Riwayat" sub="Seluruh aktivitas: barang masuk, keluar, koreksi, servis, dan opname" />
      <div className="mb-4 flex flex-wrap gap-2.5">
        <input className="input max-w-xs" placeholder="Cari barang, kode, tujuan…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input max-w-[170px]" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">Semua jenis</option>{['masuk', 'keluar', 'koreksi', 'servis', 'opname'].map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      <div className="card overflow-x-auto">
        {list.length === 0 ? <Empty>Tidak ada riwayat.</Empty> : (
          <table className="tbl">
            <thead><tr><th>Tanggal</th><th>Jenis</th><th>Barang</th><th>Detail</th><th>Oleh</th><th>Dicatat</th></tr></thead>
            <tbody>
              {list.slice(0, limit).map((r) => (
                <tr key={r.k}>
                  <td>{fd(r.date)}</td><td><span className={`tag ${TYPE_TONE[r.type]}`}>{r.type}</span></td>
                  <td>{r.item}<br /><small className="text-mu">{r.code}</small></td><td>{r.detail}</td><td>{r.by ?? '-'}</td><td><small>{fdt(r.ts)}</small></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {list.length > limit && <div className="pt-3 text-center"><button className="btn btn-ghost" onClick={() => setLimit(limit + 200)}>Tampilkan lebih banyak</button></div>}
      </div>
    </>
  )
}
