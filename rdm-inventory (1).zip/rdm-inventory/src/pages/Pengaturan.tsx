import { useProfiles } from '../lib/queries'
import { useAuth } from '../lib/auth'
import { db } from '../lib/api'
import { supabase } from '../lib/supabase'
import { fd } from '../lib/format'
import type { Role } from '../lib/types'
import { useAction } from '../components/Toast'
import { PageHeader } from '../components/ui'

const ROLES: { v: Role; l: string; d: string }[] = [
  { v: 'administrator', l: 'Administrator', d: 'Semua akses, kelola pengguna, hapus transaksi' },
  { v: 'petugas', l: 'Petugas Inventory', d: 'Master, barang masuk/keluar, servis, ajukan opname' },
  { v: 'approver', l: 'Approver', d: 'Menyetujui / menolak koreksi stock opname' },
  { v: 'viewer', l: 'Viewer', d: 'Hanya melihat data & laporan' },
]

export default function Pengaturan() {
  const { data: users = [], refetch } = useProfiles()
  const { profile } = useAuth()
  const run = useAction()

  return (
    <>
      <PageHeader title="Pengaturan" sub="Kelola pengguna dan hak akses. Akun baru otomatis berperan Viewer." />
      <div className="card mb-4 overflow-x-auto">
        <h3 className="mb-3 mt-0 text-[15px]">Pengguna</h3>
        <table className="tbl">
          <thead><tr><th>Nama</th><th>Email</th><th>Terdaftar</th><th>Peran</th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td><b>{u.full_name ?? '-'}</b></td><td>{u.email}</td><td>{fd(u.created_at)}</td>
                <td>
                  <select className="input max-w-[200px]" value={u.role} disabled={u.id === profile?.id}
                    title={u.id === profile?.id ? 'Tidak dapat mengubah peran sendiri' : ''}
                    onChange={async (e) => { await run(() => db(supabase.from('profiles').update({ role: e.target.value }).eq('id', u.id)), 'Peran diperbarui'); refetch() }}>
                    {ROLES.map((r) => <option key={r.v} value={r.v}>{r.l}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="card">
        <h3 className="mb-3 mt-0 text-[15px]">Hak akses per peran</h3>
        {ROLES.map((r) => <div key={r.v} className="flex gap-3 border-b border-bd py-2 last:border-0"><b className="w-40 shrink-0">{r.l}</b><span className="text-mu">{r.d}</span></div>)}
      </div>
    </>
  )
}
