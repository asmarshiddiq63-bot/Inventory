import { useMemo, useState } from 'react'
import { useItems, useOpnames } from '../lib/queries'
import { useAuth } from '../lib/auth'
import { rpc } from '../lib/api'
import { fd } from '../lib/format'
import { useAction, useToast } from '../components/Toast'
import { Empty, PageHeader, TYPE_TONE } from '../components/ui'

export default function Opname() {
  const { data: items = [] } = useItems()
  const { data: ops = [] } = useOpnames()
  const { canWrite, canApprove } = useAuth()
  const run = useAction()
  const toast = useToast()
  const [phys, setPhys] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)

  const persediaan = items.filter((i) => i.kind === 'persediaan')
  const map = useMemo(() => new Map(items.map((i) => [i.id, i])), [items])
  const pending = new Set(ops.filter((o) => o.status === 'menunggu').map((o) => o.item_id))

  async function submit() {
    const entries = Object.entries(phys).filter(([, v]) => v !== '')
    if (!entries.length) return toast('Isi minimal satu stok fisik', 'err')
    setBusy(true)
    let n = 0
    for (const [id, v] of entries) {
      const p = Math.floor(Number(v))
      if (isNaN(p) || p < 0) { toast('Stok fisik tidak valid', 'err'); break }
      const ok = await run(() => rpc('rpc_submit_opname', { p_item: id, p_physical: p, p_note: null }), `Opname diajukan`)
      if (!ok) break
      n++
    }
    setBusy(false)
    if (n) setPhys({})
  }

  return (
    <>
      <PageHeader title="Stock Opname" sub="Hitung fisik persediaan; koreksi stok baru berlaku setelah disetujui approver">
        {canWrite && <button className="btn" disabled={busy} onClick={submit}>Ajukan hasil opname</button>}
      </PageHeader>

      <div className="card mb-4 overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>Kode</th><th>Barang</th><th>Stok sistem</th><th className="w-36">Stok fisik</th><th>Selisih</th></tr></thead>
          <tbody>
            {persediaan.map((i) => {
              const v = phys[i.id] ?? ''
              const d = v === '' ? null : Number(v) - i.stock
              return (
                <tr key={i.id}>
                  <td>{i.code}</td><td>{i.name}{pending.has(i.id) && <span className="tag t-warn ml-2">menunggu persetujuan</span>}</td><td>{i.stock}</td>
                  <td><input className="input" type="number" min={0} disabled={!canWrite || pending.has(i.id)} placeholder={String(i.stock)} value={v} onChange={(e) => setPhys({ ...phys, [i.id]: e.target.value })} /></td>
                  <td>{d === null ? '-' : <span className={`tag ${d < 0 ? 't-danger' : d > 0 ? 't-ok' : 't-teal'}`}>{d > 0 ? '+' : ''}{d}</span>}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {persediaan.length === 0 && <Empty>Belum ada barang persediaan.</Empty>}
      </div>

      <div className="card overflow-x-auto">
        <h3 className="mb-3 mt-0 text-[15px]">Riwayat & persetujuan opname</h3>
        {ops.length === 0 ? <Empty>Belum ada opname.</Empty> : (
          <table className="tbl">
            <thead><tr><th>Tanggal</th><th>Barang</th><th>Sistem</th><th>Fisik</th><th>Selisih</th><th>Status</th><th /></tr></thead>
            <tbody>
              {ops.slice(0, 100).map((o) => (
                <tr key={o.id}>
                  <td>{fd(o.opname_date)}</td><td>{map.get(o.item_id)?.name ?? '(dinonaktifkan)'}</td><td>{o.system_qty}</td><td>{o.physical_qty}</td>
                  <td><span className={`tag ${o.diff < 0 ? 't-danger' : o.diff > 0 ? 't-ok' : 't-teal'}`}>{o.diff > 0 ? '+' : ''}{o.diff}</span></td>
                  <td><span className={`tag ${TYPE_TONE[o.status]}`}>{o.status}</span></td>
                  <td className="whitespace-nowrap">
                    {o.status === 'menunggu' && canApprove && (
                      <>
                        <button className="btn btn-sm" onClick={() => run(() => rpc('rpc_review_opname', { p_id: o.id, p_approve: true }), 'Opname disetujui, stok dikoreksi')}>Setujui</button>{' '}
                        <button className="btn btn-danger btn-sm" onClick={() => run(() => rpc('rpc_review_opname', { p_id: o.id, p_approve: false }), 'Opname ditolak')}>Tolak</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  )
}
