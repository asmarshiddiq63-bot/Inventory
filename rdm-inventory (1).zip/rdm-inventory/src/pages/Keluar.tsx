import { useMemo, useState } from 'react'
import { useItems, useMovements } from '../lib/queries'
import { useAuth } from '../lib/auth'
import { rpc } from '../lib/api'
import { fd, today, toks } from '../lib/format'
import type { Movement } from '../lib/types'
import { useAction, useConfirm, useToast } from '../components/Toast'
import { Empty, Field, FormGrid, ItemSelect, Modal, PageHeader } from '../components/ui'

export default function Keluar() {
  const { data: items = [] } = useItems()
  const { data: mv = [] } = useMovements()
  const { canWrite, isAdmin } = useAuth()
  const run = useAction()
  const confirm = useConfirm()
  const [form, setForm] = useState<Movement | 'new' | null>(null)
  const map = useMemo(() => new Map(items.map((i) => [i.id, i])), [items])
  const rows = mv.filter((m) => m.type === 'keluar')

  async function del(id: string) {
    if (await confirm('Hapus transaksi? Stok akan dikembalikan.')) await run(() => rpc('rpc_delete_movement', { p_id: id }), 'Transaksi dihapus')
  }

  return (
    <>
      <PageHeader title="Barang Keluar" sub="Distribusi barang & aset — stok tidak bisa menjadi minus">
        {canWrite && <button className="btn" onClick={() => setForm('new')}>+ Barang keluar</button>}
      </PageHeader>
      <div className="card overflow-x-auto">
        {rows.length === 0 ? <Empty>Belum ada barang keluar.</Empty> : (
          <table className="tbl">
            <thead><tr><th>Tanggal</th><th>Barang</th><th>Qty</th><th>Tujuan / penerima</th><th>Catatan</th><th /></tr></thead>
            <tbody>
              {rows.map((t) => {
                const i = map.get(t.item_id)
                return (
                  <tr key={t.id}>
                    <td>{fd(t.movement_date)}</td>
                    <td>{i?.name ?? '(dinonaktifkan)'}<br /><small className="text-mu">{i?.code}{t.serials?.length ? ` · SN: ${t.serials.join(', ')}` : ''}</small></td>
                    <td><b>{t.qty}</b></td>
                    <td>{t.party ?? '-'}</td>
                    <td>{t.note ?? ''}</td>
                    <td className="whitespace-nowrap">
                      {canWrite && <button className="btn btn-ghost btn-sm" onClick={() => setForm(t)}>Edit</button>}{' '}
                      {isAdmin && <button className="btn btn-danger btn-sm" onClick={() => del(t.id)}>Hapus</button>}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
      {form && <KeluarForm move={form === 'new' ? undefined : form} onClose={() => setForm(null)} />}
    </>
  )
}

function KeluarForm({ move, onClose }: { move?: Movement; onClose: () => void }) {
  const { data: items = [] } = useItems()
  const run = useAction()
  const toast = useToast()
  const [f, setF] = useState({ item: move?.item_id ?? '', qty: String(move?.qty ?? 1), date: move?.movement_date ?? today(), party: move?.party ?? '', note: move?.note ?? '', sn: move?.serials?.join(', ') ?? '' })
  const sel = items.find((i) => i.id === f.item)
  const avail = sel ? sel.stock + (move ? move.qty : 0) : 0

  async function save() {
    const qty = Math.floor(Number(f.qty))
    if (!sel) return toast('Pilih barang', 'err')
    if (!(qty > 0)) return toast('Jumlah tidak valid', 'err')
    if (qty > avail) return toast(`Stok tidak cukup (tersedia ${avail})`, 'err')
    if (toks(f.sn).length > qty) return toast('Jumlah serial number melebihi jumlah keluar', 'err')
    const ok = await run(() => move
      ? rpc('rpc_update_stock_out', { p_id: move.id, p_qty: qty, p_date: f.date, p_party: f.party, p_note: f.note })
      : rpc('rpc_stock_out', { p_item: sel.id, p_qty: qty, p_date: f.date, p_party: f.party, p_note: f.note, p_serials: toks(f.sn) }), 'Barang keluar tersimpan')
    if (ok) onClose()
  }

  return (
    <Modal title={move ? 'Edit Barang Keluar' : 'Barang Keluar'} onClose={onClose} footer={<><button className="btn btn-ghost" onClick={onClose}>Batal</button><button className="btn" onClick={save}>Simpan</button></>}>
      <FormGrid>
        <Field label="Barang" span>
          <ItemSelect items={items} value={f.item} onChange={(v) => setF({ ...f, item: v })} disabled={!!move} />
          {sel && <small className="text-mu">Kode {sel.code} · tersedia {avail} {sel.unit}</small>}
        </Field>
        <Field label="Jumlah"><input className="input" type="number" min={1} value={f.qty} onChange={(e) => setF({ ...f, qty: e.target.value })} /></Field>
        <Field label="Tanggal"><input className="input" type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
        <Field label="Tujuan / penerima" span><input className="input" value={f.party} onChange={(e) => setF({ ...f, party: e.target.value })} placeholder="mis. Divisi IT / Site Duri" /></Field>
        {!move && <Field label="Serial number unit yang keluar" span><input className="input" value={f.sn} onChange={(e) => setF({ ...f, sn: e.target.value })} placeholder="Opsional — pisahkan koma bila lebih dari satu" /></Field>}
        <Field label="Catatan" span><input className="input" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field>
      </FormGrid>
    </Modal>
  )
}
